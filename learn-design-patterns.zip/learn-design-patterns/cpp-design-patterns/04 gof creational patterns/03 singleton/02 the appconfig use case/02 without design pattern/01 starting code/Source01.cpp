/*
- Basic AppConfig class which can be instantiated any number of times.
*/

#include <iostream>
#include <mutex>
#include <string>
#include <unordered_map>

class AppConfig {
public:
	std::string& operator[](const std::string& key);
private:
	std::unordered_map<std::string, std::string> m_configMap;
};

std::string& AppConfig::operator[](const std::string& key) {
	return m_configMap[key];
}

int main() {
	AppConfig appConfig;

	// Set configuration values
	appConfig["database_url"] = "jdbc:mysql://localhost:3306/my_database";
	appConfig["server_port"] = "8080";

	// Output the configuration values
	std::cout << "Database URL: " << appConfig["database_url"] << std::endl;
	std::cout << "Server Port: " << appConfig["server_port"] << std::endl;

	return 0;
}

/*
- Why it doesn't make sense to create another instance of AppConfig class?
  AppConfig typically holds configuration settings
  The settings should be accessed uniformly throughout the application.
  Creating multiple instances could lead to inconsistencies or unnecessary duplication of configuration data.
*/