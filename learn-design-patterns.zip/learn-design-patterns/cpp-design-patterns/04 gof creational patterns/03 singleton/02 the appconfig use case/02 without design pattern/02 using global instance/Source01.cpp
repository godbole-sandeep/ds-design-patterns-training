/*
- Using global instance of AppConfig class.
*/

#include <iostream>
#include <string>
#include <unordered_map>

class AppConfig {
public:
	std::string& operator[](const std::string& key);
private:
	std::unordered_map<std::string, std::string> m_configMap;
};

std::string& AppConfig::operator[](const std::string& key) {
	return m_configMap[key];
}

AppConfig appConfig;

int main() {
	// Set configuration values
	appConfig["database_url"] = "jdbc:mysql://localhost:3306/my_database";
	appConfig["server_port"] = "8080";

	// Output the configuration values
	std::cout << "Database URL: " << appConfig["database_url"] << std::endl;
	std::cout << "Server Port: " << appConfig["server_port"] << std::endl;

	return 0;
}

/*
- Declaring a global object of the AppConfig class allows access to configuration
  from any part of the application.
- This makes it unnecessary to define another instance of AppConfig.
- Though it's a working solution, it's not a complete solution as a user can still
  create another instance of AppConfig.
- We want a more formal solution that will restrict users from creating another
  instance of the AppConfig class.
*/