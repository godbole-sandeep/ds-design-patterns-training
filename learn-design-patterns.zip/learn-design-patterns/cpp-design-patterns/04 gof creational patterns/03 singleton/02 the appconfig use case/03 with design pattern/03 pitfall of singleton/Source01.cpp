/*
- Drawback of accessing a singleton directly from within a function.
*/

#include <iostream>
#include <string>
#include <unordered_map>

class AppConfig {
private:
	AppConfig() = default;
	~AppConfig() = default;
private:
	AppConfig(const AppConfig&) = delete;
	AppConfig& operator=(const AppConfig&) = delete;
public:
	static AppConfig& GetInstance(); // change in function name and return type
public:
	std::string& operator[](const std::string& key);
private:
	std::unordered_map<std::string, std::string> m_configMap;
	static AppConfig m_instance; // change in type
};

AppConfig AppConfig::m_instance;

AppConfig& AppConfig::GetInstance() {
	return m_instance;
}

std::string& AppConfig::operator[](const std::string& key) {
	return m_configMap[key];
}

// Function to corrupt the database_url setting
void CorruptDatabaseUrl() {
	AppConfig& appConfig = AppConfig::GetInstance();

	// Access database_url property value
	std::string& dbUrl = appConfig["database_url"];

	// Append random characters to the database URL
	std::string corruption = "xyz123";
	dbUrl += corruption;
}

int main() {
	AppConfig& appConfig = AppConfig::GetInstance();

	// Set configuration values
	appConfig["database_url"] = "jdbc:mysql://localhost:3306/my_database";
	appConfig["server_port"] = "8080";

	// Output the configuration values
	std::cout << "Database URL: " << appConfig["database_url"] << std::endl;
	std::cout << "Server Port: " << appConfig["server_port"] << std::endl;

	CorruptDatabaseUrl();

	// Output the configuration values
	std::cout << "Database URL: " << appConfig["database_url"] << std::endl;
	std::cout << "Server Port: " << appConfig["server_port"] << std::endl;

	return 0;
}

/*
- Singletons, by their nature, hide dependencies.
*/