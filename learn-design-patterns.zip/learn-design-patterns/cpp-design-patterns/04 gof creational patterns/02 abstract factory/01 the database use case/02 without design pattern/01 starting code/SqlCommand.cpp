#include <string>

#include "SqlCommand.h"
#include "SqlConnection.h"
#include "SqlDataReader.h"

// Parametric constructor implementation
SqlCommand::SqlCommand(const std::string& cmdText, SqlConnection& connection)
    : m_cmdText(cmdText), m_connection(connection) {}

// Method to execute the command and return a reader
SqlDataReader SqlCommand::ExecuteReader() {
    // Placeholder implementation for ExecuteReader method
    // You can replace this with actual implementation to execute the command and return a reader
    return SqlDataReader();
}