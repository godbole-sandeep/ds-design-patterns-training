#pragma once

struct Variant {};