#include <exception>
#include <iostream>
#include <string>
#include <variant>

#include "SqlCommand.h"
#include "SqlConnection.h"
#include "SqlDataReader.h"

int main() {
    // Connection String
    std::string connString = "Data Source=(local);Initial Catalog=Northwind; Integrated Security=SSPI";

    // Create SqlConnection instance
    SqlConnection connection(connString);

    // Open connection to Sql Server
    connection.Open();

    // Sql query string
    std::string queryString = "SELECT ID, Name, Balance FROM dbo.Accounts;";

    // Create SqlCommand instance
    SqlCommand command(queryString, connection);

    // Create SqlDataReader instance
    SqlDataReader reader = command.ExecuteReader();

    // Read and print data
    while (reader.Read()) {
        try {
            std::cout << "ID: " << std::get<int>(reader["ID"]) << ", "
                << "Name: " << std::get<std::string>(reader["Name"]) << ", "
                << "Balance: " << std::get<double>(reader["Balance"]) << "\n";
        }
        catch (const std::bad_variant_access& e) {
            std::cerr << "Bad variant access: " << e.what() << '\n';
        }
        catch (const std::exception& e) {
            std::cerr << "Exception: " << e.what() << '\n';
        }
    }

    // Close reader
    reader.Close();

    // Close connection
    connection.Close();

    return 0;
}

/*
- Following are the major drawbacks of this code:
- Tight coupling occurs when the client code is intricately linked to specific
  classes such as SqlConnection, SqlCommand, SqlDataReader, etc., thus making
  it challenging to switch to alternative database classes without necessitating
  modifications to the client code.
- Lack of Flexibility: The design doesn't support easily switching between different
  families of database classes.
*/