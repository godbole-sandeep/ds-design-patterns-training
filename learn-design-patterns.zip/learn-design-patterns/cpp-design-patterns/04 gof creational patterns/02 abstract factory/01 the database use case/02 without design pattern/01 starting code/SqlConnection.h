#pragma once

#include <string>

class SqlConnection {
public:
    // Parametric constructor
    SqlConnection(const std::string& connectionString);

    // Method to open the connection
    void Open();

    // Method to close the connection
    void Close();

private:
    std::string m_connectionString;
};