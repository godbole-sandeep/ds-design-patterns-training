#pragma once

#include <string>

#include "SqlConnection.h"
#include "SqlDataReader.h"

class SqlCommand {
public:
    // Parametric constructor
    SqlCommand(const std::string& cmdText, SqlConnection& connection);

    // Method to execute the command and return a reader
    SqlDataReader ExecuteReader();

private:
    std::string m_cmdText;
    SqlConnection& m_connection;
};