#include <exception>
#include <iostream>
#include <memory>
#include <string>
#include <variant>

#include "DbCommand.h"
#include "DbConnection.h"
#include "DbDataReader.h"
#include "SqlCommand.h"
#include "SqlConnection.h"

int main() {
    // Connection String
    std::string connString = "Data Source=(local);Initial Catalog=Northwind; Integrated Security=SSPI";

    // Create SqlConnection instance
    std::unique_ptr<DbConnection> connectionPtr(new SqlConnection(connString));
   
    // Open connection to Sql Server
    connectionPtr->Open();

    // Sql query string
    std::string queryString = "SELECT ID, Name, Balance FROM dbo.Accounts;";

    // Create SqlCommand instance
    std::unique_ptr<DbCommand> commandPtr(new SqlCommand(queryString, *dynamic_cast<SqlConnection*>(connectionPtr.get())));

    // Create SqlDataReader instance
    std::shared_ptr<DbDataReader> readerPtr = commandPtr->ExecuteReader();

    // Read and print data
    while (readerPtr->Read()) {
        try {
            std::cout << "ID: " << std::get<int>((*readerPtr)["ID"]) << ", "
                << "Name: " << std::get<std::string>((*readerPtr)["Name"]) << ", "
                << "Balance: " << std::get<double>((*readerPtr)["Balance"]) << "\n";
        }
        catch (const std::bad_variant_access& e) {
            std::cerr << "Bad variant access: " << e.what() << '\n';
        }
        catch (const std::exception& e) {
            std::cerr << "Exception: " << e.what() << '\n';
        }
    }

    // Close reader
    readerPtr->Close();

    // Close connection
    connectionPtr->Close();

    return 0;
}

/*
- The following changes have been made to the project to support the new abstraction:
  1. Introduced new interfaces: DbConnection, DbCommand, and DbDataReader.
  2. SqlConnection now inherits from DbConnection, SqlCommand from DbCommand, and
     SqlDataReader from DbDataReader.
  3. Updated SqlCommand::ExecuteReader() to return the same type as DbCommand::ExecuteReader().
  4. Revised the code in the main function to align with the project's modifications.
- Despite the introduction of base classes like DbConnection, DbCommand, and DbDataReader, and
  the rewriting of the main function to utilize these base classes, the code still references specific
  classes like SqlConnection, SqlCommand, and SqlDataReader. While these modifications have
  reduced the tight coupling to some extent, they have not completely eliminated it.
- Implement an abstract factory to eliminate tight coupling.
*/