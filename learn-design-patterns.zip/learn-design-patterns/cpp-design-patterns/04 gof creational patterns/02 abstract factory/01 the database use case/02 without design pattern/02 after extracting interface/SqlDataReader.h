#pragma once

#include <map>
#include <string>
#include <variant>
#include <vector>

#include "DbDataReader.h"

class SqlDataReader : public DbDataReader {
public:
    using VariantType = std::variant<int, double, std::string>;

public:
    // Default constructor
    SqlDataReader();

    // Method to close the reader
    void Close();

    // Method to read the next row
    bool Read();

    // Overloaded [] operator to access column data
    VariantType operator[](const std::string& columnName) const;

private:
    std::vector<std::map<std::string, VariantType>> m_data;
    size_t m_currentRow;
    bool m_isClosed;
};