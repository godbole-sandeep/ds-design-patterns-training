#pragma once

#include <string>
#include <variant>

class DbDataReader {
public:
    // Virtual destructor
    virtual ~DbDataReader() = default;

    // Method to read the next row of data
    virtual bool Read() = 0;

    // Method to retrieve data from the current row
    virtual std::variant<int, double, std::string> operator[](const std::string& columnName) const = 0;

    // Method to close the reader
    virtual void Close() = 0;
};