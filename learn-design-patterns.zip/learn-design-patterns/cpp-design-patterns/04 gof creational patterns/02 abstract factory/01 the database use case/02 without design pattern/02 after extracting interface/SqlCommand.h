#pragma once

#include <memory>
#include <string>

#include "DbCommand.h"
#include "DbDataReader.h"
#include "SqlConnection.h"

class SqlCommand : public DbCommand {
public:
    // Parametric constructor
    SqlCommand(const std::string& cmdText, SqlConnection& connection);

    // Method to execute the command and return a reader
    virtual std::shared_ptr<DbDataReader> ExecuteReader();

private:
    std::string m_cmdText;
    SqlConnection& m_connection;
};