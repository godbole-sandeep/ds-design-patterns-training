#pragma once

class DbConnection {
public:
    virtual ~DbConnection() = default;
public:
    // Method to open the connection
    virtual void Open() = 0;

    // Method to close the connection
    virtual void Close() = 0;
};