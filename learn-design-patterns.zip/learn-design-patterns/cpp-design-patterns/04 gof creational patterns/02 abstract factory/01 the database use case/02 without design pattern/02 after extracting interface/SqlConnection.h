#pragma once

#include <string>

#include "DbConnection.h"

class SqlConnection : public DbConnection {
public:
    // Parametric constructor
    SqlConnection(const std::string& connectionString);

    // Method to open the connection
    void Open();

    // Method to close the connection
    void Close();

private:
    std::string m_connectionString;
};