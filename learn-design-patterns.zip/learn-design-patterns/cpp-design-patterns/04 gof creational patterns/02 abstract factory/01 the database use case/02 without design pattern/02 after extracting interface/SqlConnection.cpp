#include <iostream>
#include <string>

#include "SqlConnection.h"

// Parametric constructor implementaion
SqlConnection::SqlConnection(const std::string& connectionString)
    : m_connectionString(connectionString) {}

// Method to open the connection
void SqlConnection::Open() {
    std::cout << "Opening SQL connection with connection string: " << m_connectionString << "\n";
}

// Method to close the connection
void SqlConnection::Close() {
    std::cout << "Closing SQL connection.\n";
}