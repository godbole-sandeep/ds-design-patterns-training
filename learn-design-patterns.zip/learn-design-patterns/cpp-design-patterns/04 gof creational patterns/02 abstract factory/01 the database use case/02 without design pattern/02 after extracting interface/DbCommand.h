#pragma once

#include <memory>

#include "DbDataReader.h"

class DbCommand {
public:
    virtual ~DbCommand() = default;
public:
    virtual std::shared_ptr<DbDataReader> ExecuteReader() = 0;
};