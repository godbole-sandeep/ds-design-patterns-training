#include <memory>

#include "DbCommand.h"
#include "DbConnection.h"
#include "OracleCommand.h"
#include "OracleConnection.h"
#include "OracleProviderFactory.h"

std::shared_ptr<DbConnection> OracleProviderFactory::CreateConnection() {
	return std::shared_ptr<OracleConnection>(new OracleConnection());
}

std::shared_ptr<DbCommand> OracleProviderFactory::CreateCommand() {
	return std::shared_ptr<OracleCommand>(new OracleCommand());
}