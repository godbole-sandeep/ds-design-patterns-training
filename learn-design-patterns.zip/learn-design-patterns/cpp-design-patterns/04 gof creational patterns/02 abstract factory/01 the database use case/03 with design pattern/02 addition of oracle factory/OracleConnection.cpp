#include <iostream>
#include <string>

#include "OracleConnection.h"

OracleConnection::OracleConnection()
    : m_connectionString("") {}

// Parametric constructor implementaion
OracleConnection::OracleConnection(const std::string& connectionString)
    : m_connectionString(connectionString) {}

void OracleConnection::SetConnectionString(const std::string& connectionString) {
    m_connectionString = connectionString;
}

std::string OracleConnection::GetConnectionString() const {
    return m_connectionString;
}

// Method to open the connection
void OracleConnection::Open() {
    std::cout << "Opening Oracle connection with connection string: " << m_connectionString << "\n";
}

// Method to close the connection
void OracleConnection::Close() {
    std::cout << "Closing Oracle connection.\n";
}