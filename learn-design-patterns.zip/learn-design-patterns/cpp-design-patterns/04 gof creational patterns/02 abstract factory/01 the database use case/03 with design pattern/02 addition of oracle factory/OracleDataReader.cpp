#include <iostream>
#include <map>
#include <stdexcept>
#include <string>
#include <vector>

#include "OracleDataReader.h"

// Default constructor implementation
OracleDataReader::OracleDataReader()
    : m_currentRow(0), m_isClosed(false) {
    std::vector<std::map<std::string, OracleDataReader::VariantType>> data = {
            {{"ID", 1}, {"Name", std::string("Alice")}, {"Balance", 1000.50}},
            {{"ID", 2}, {"Name", std::string("Bob")}, {"Balance", 850.75}}
    };
    m_data = data;
}

// Method to close the reader
void OracleDataReader::Close() {
    m_isClosed = true;
    std::cout << "OracleDataReader closed.\n";
}

// Method to read the next row
bool OracleDataReader::Read() {
    if (m_isClosed || m_currentRow >= m_data.size()) {
        return false;
    }
    ++m_currentRow;
    return true;
}

// Overloaded [] operator to access column data
OracleDataReader::VariantType OracleDataReader::operator[](const std::string& columnName) const {
    if (m_isClosed || m_currentRow == 0 || m_currentRow > m_data.size()) {
        throw std::out_of_range("No current row or reader is closed.");
    }
    const auto& row = m_data[m_currentRow - 1];
    auto it = row.find(columnName);
    if (it != row.end()) {
        return it->second;
    }
    else {
        throw std::invalid_argument("Column name does not exist.");
    }
}