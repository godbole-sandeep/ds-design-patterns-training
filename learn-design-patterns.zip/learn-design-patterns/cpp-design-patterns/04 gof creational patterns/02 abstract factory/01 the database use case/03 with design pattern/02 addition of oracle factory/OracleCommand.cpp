#include <memory>
#include <string>

#include "DbConnection.h"
#include "DbDataReader.h"
#include "OracleCommand.h"
#include "OracleConnection.h"
#include "OracleDataReader.h"

OracleCommand::OracleCommand() : m_cmdText("") {}

// Parametric constructor implementation
OracleCommand::OracleCommand(const std::string& cmdText, OracleConnection& connection)
    : m_cmdText(cmdText), m_connectionPtr(&connection) {}

void OracleCommand::SetCommandText(const std::string& cmdText) {
    m_cmdText = cmdText;
}

std::string OracleCommand::GetCommandText() const {
    return m_cmdText;
}

void OracleCommand::SetConnection(DbConnection& connection) {
    m_connectionPtr = &connection;
}

DbConnection& OracleCommand::GetConnection() {
    return *m_connectionPtr;
}

// Method to execute the command and return a reader
std::shared_ptr<DbDataReader> OracleCommand::ExecuteReader() {
    // Placeholder implementation for ExecuteReader method
    // You can replace this with actual implementation to execute the command and return a reader
    return std::make_shared<OracleDataReader>();
}