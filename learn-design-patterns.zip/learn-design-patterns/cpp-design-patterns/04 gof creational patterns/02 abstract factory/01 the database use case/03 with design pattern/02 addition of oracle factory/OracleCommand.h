#pragma once

#include <memory>
#include <string>

#include "DbCommand.h"
#include "DbConnection.h"
#include "DbDataReader.h"
#include "OracleConnection.h"

class OracleCommand : public DbCommand {
public:
    // Default constructor
    OracleCommand();

    // Parametric constructor
    OracleCommand(const std::string& cmdText, OracleConnection& connection);

    // Method to set the command text
    void SetCommandText(const std::string& cmdText) override;

    // Method to get the command text
    std::string GetCommandText() const override;

    // Method to set the command text
    virtual void SetConnection(DbConnection& connection) override;

    // Method to get the command text
    virtual DbConnection& GetConnection() override;

    // Method to execute the command and return a reader
    virtual std::shared_ptr<DbDataReader> ExecuteReader();

private:
    std::string m_cmdText;
    DbConnection* m_connectionPtr;
};