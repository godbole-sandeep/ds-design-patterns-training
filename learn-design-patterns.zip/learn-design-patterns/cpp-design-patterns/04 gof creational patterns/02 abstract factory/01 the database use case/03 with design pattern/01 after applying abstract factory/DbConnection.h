#pragma once
#include <string>

class DbConnection {
public:
    // Virtual destructor
    virtual ~DbConnection() = default;

    // Method to set the connection string
    virtual void SetConnectionString(const std::string& connectionString) = 0;

    // Method to get the connection string
    virtual std::string GetConnectionString() const = 0;

    // Method to open the connection
    virtual void Open() = 0;

    // Method to close the connection
    virtual void Close() = 0;
};