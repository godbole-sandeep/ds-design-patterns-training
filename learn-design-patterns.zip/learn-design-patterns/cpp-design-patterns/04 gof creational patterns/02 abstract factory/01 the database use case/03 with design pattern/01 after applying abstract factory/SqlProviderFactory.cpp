#include <memory>

#include "DbCommand.h"
#include "DbConnection.h"
#include "SqlCommand.h"
#include "SqlConnection.h"
#include "SqlProviderFactory.h"

std::shared_ptr<DbConnection> SqlProviderFactory::CreateConnection() {
	return std::shared_ptr<SqlConnection>(new SqlConnection());
}

std::shared_ptr<DbCommand> SqlProviderFactory::CreateCommand() {
	return std::shared_ptr<SqlCommand>(new SqlCommand());
}