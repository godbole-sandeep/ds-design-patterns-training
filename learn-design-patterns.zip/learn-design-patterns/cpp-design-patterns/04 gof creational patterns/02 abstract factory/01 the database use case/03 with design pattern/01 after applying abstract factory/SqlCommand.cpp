#include <memory>
#include <string>

#include "DbConnection.h"
#include "DbDataReader.h"
#include "SqlCommand.h"
#include "SqlConnection.h"
#include "SqlDataReader.h"

SqlCommand::SqlCommand() : m_cmdText("") {}

// Parametric constructor implementation
SqlCommand::SqlCommand(const std::string& cmdText, SqlConnection& connection)
    : m_cmdText(cmdText), m_connectionPtr(&connection) {}

void SqlCommand::SetCommandText(const std::string& cmdText) {
    m_cmdText = cmdText;
}

std::string SqlCommand::GetCommandText() const {
    return m_cmdText;
}

void SqlCommand::SetConnection(DbConnection& connection) {
    m_connectionPtr = &connection;
}

DbConnection& SqlCommand::GetConnection() {
    return *m_connectionPtr;
}

// Method to execute the command and return a reader
std::shared_ptr<DbDataReader> SqlCommand::ExecuteReader() {
    // Placeholder implementation for ExecuteReader method
    // You can replace this with actual implementation to execute the command and return a reader
    return std::make_shared<SqlDataReader>();
}