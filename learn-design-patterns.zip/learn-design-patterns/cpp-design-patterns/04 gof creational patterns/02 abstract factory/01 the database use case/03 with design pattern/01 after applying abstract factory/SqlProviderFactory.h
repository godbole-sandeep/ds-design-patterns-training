#pragma once

#include <memory>

#include "DbCommand.h"
#include "DbConnection.h"
#include "DbProviderFactory.h"

class SqlProviderFactory : public DbProviderFactory {
public:
	// Creates DbConnection instance
	virtual std::shared_ptr<DbConnection> CreateConnection();

	// Creates DbCommand instance
	virtual std::shared_ptr<DbCommand> CreateCommand();
};