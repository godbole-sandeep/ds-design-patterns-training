#include <iostream>
#include <memory>

#include <exception>
#include <string>
#include <variant>
#include "DbCommand.h"
#include "DbConnection.h"
#include "DbDataReader.h"
#include "DbProviderFactory.h"
#include "SqlProviderFactory.h"

int main() {
    // Create SqlProviderFactory instance
    std::unique_ptr<DbProviderFactory> factoryPtr(new SqlProviderFactory());

    // Connection String
    std::string connString = "Data Source=(local);Initial Catalog=Northwind; Integrated Security=SSPI";

    // Create SqlConnection instance
    std::shared_ptr<DbConnection> connectionPtr = factoryPtr->CreateConnection();
    connectionPtr->SetConnectionString(connString);
   
    // Open connection to Sql Server
    connectionPtr->Open();

    // Sql query string
    std::string queryString = "SELECT ID, Name, Balance FROM dbo.Accounts;";

    // Create SqlCommand instance
    std::shared_ptr<DbCommand> commandPtr = factoryPtr->CreateCommand();
    commandPtr->SetCommandText(queryString);
    commandPtr->SetConnection(*connectionPtr);

    // Create SqlDataReader instance
    std::shared_ptr<DbDataReader> readerPtr = commandPtr->ExecuteReader();

    // Read and print data
    while (readerPtr->Read()) {
        try {
            std::cout << "ID: " << std::get<int>((*readerPtr)["ID"]) << ", "
                << "Name: " << std::get<std::string>((*readerPtr)["Name"]) << ", "
                << "Balance: " << std::get<double>((*readerPtr)["Balance"]) << "\n";
        }
        catch (const std::bad_variant_access& e) {
            std::cerr << "Bad variant access: " << e.what() << '\n';
        }
        catch (const std::exception& e) {
            std::cerr << "Exception: " << e.what() << '\n';
        }
    }

    // Close reader
    readerPtr->Close();

    // Close connection
    connectionPtr->Close();

    return 0;
}

/*
- To eliminate tight coupling, additional abstraction is necessary, which can be achieved using an abstract factory.
*/