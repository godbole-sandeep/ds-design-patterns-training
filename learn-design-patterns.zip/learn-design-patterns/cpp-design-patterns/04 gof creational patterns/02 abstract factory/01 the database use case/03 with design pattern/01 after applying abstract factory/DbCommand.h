#pragma once

#include <memory>

#include "DbConnection.h"
#include "DbDataReader.h"
#include <string>

class DbCommand {
public:
    virtual ~DbCommand() = default;
public:
    // Method to set the command text
    virtual void SetCommandText(const std::string& cmdText) = 0;

    // Method to get the command text
    virtual std::string GetCommandText() const = 0;

    // Method to set the command text
    virtual void SetConnection(DbConnection& connection) = 0;

    // Method to get the command text
    virtual DbConnection& GetConnection() = 0;

    // Method to execute the command and return a data reader
    virtual std::shared_ptr<DbDataReader> ExecuteReader() = 0;
};