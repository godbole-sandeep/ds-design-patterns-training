#pragma once

#include <string>

#include "DbConnection.h"

class SqlConnection : public DbConnection {
public:
    // Default constructor
    SqlConnection();

    // Parametric constructor
    SqlConnection(const std::string& connectionString);

    // Method to set the connection string
    void SetConnectionString(const std::string& connectionString) override;

    // Method to get the connection string
    std::string GetConnectionString() const override;

    // Method to open the connection
    void Open();

    // Method to close the connection
    void Close();

private:
    std::string m_connectionString;
};