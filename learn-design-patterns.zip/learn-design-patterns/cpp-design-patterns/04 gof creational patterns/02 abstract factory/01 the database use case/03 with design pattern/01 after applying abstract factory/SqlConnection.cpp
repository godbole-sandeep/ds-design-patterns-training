#include <iostream>
#include <string>

#include "SqlConnection.h"

SqlConnection::SqlConnection()
    : m_connectionString("") {}

// Parametric constructor implementaion
SqlConnection::SqlConnection(const std::string& connectionString)
    : m_connectionString(connectionString) {}

void SqlConnection::SetConnectionString(const std::string& connectionString) {
    m_connectionString = connectionString;
}

std::string SqlConnection::GetConnectionString() const {
    return m_connectionString;
}

// Method to open the connection
void SqlConnection::Open() {
    std::cout << "Opening SQL connection with connection string: " << m_connectionString << "\n";
}

// Method to close the connection
void SqlConnection::Close() {
    std::cout << "Closing SQL connection.\n";
}