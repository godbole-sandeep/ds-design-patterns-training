#pragma once

#include <memory>

#include "DbCommand.h"
#include "DbConnection.h"

class DbProviderFactory {
public:
	// Creates DbConnection instance
	virtual std::shared_ptr<DbConnection> CreateConnection() = 0;

	// Creates DbCommand instance
	virtual std::shared_ptr<DbCommand> CreateCommand() = 0;
};