#pragma once

class Point{
public:
	Point(double x = 0, double y = 0);
public:
	double GetX() const;
	double GetY() const;
	void SetX(double value);
	void SetY(double value);
private:
	double m_x;
	double m_y;
};