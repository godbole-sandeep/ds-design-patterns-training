#include <iostream>

#include "Point.h"

int main() {
    // Create a Point object
    Point point;

    // Set some values
    point.SetX(42);
    point.SetY(20);

    // Output the values
    std::cout << "X: " << point.GetX() << ", Y: " << point.GetY() << std::endl;

    return 0;
}
/*
- Assuming `Point` is a critical class whose implementation details the author wants to hide.
- However, this cannot be achieved with the present design.
- The Point class adheres to SRP.
- Generally, the design of the Point class follows SOLID principles.
*/