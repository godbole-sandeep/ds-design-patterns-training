#pragma once

class IPoint {
public:
	virtual ~IPoint() = default;
public:
	virtual double GetX() const = 0;
	virtual double GetY() const = 0;
	virtual void SetX(double value) = 0;
	virtual void SetY(double value) = 0;
};