#include <iostream>
#include <memory>

#include "IFactory.h"
#include "IPoint.h"
#include "PointFactory.h"

int main() {
    // Create a PointFactory
    std::unique_ptr<IFactory> factory = std::make_unique<PointFactory>();

    // Use the factory to create a Point object
    std::unique_ptr<IPoint> point(static_cast<IPoint*>(factory->CreateObject()));

    // Set some values
    point->SetX(42);
    point->SetY(20);

    // Output the values
    std::cout << "X: " << point->GetX() << ", Y: " << point->GetY() << std::endl;

    // The smart pointers will automatically clean up the resources
    return 0;
}

/*
- With the use of the factory method design pattern, the author successfully hides
  the implementation details of the Point class.
- The drawback of `IFactory::CreateObject` is that it is not type-safe.
*/