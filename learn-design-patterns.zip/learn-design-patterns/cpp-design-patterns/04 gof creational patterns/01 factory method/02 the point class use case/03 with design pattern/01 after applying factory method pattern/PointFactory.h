#pragma once

#include "IFactory.h"
#include "IPoint.h"

class PointFactory : public IFactory {
public:
	void* CreateObject() override;
};