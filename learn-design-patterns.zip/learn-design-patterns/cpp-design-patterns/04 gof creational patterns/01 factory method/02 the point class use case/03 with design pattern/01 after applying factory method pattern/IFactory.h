#pragma once

class IFactory {
public:
	virtual void* CreateObject() = 0;
};