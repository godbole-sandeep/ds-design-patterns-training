#include "Point.h"
#include "PointFactory.h"

void* PointFactory::CreateObject() {
	return new Point();
}