#include <memory>

#include "GasEngineCarFactory.h"
#include "ICar.h"
#include "ICarFactory.h"
#include "MockEngineCarFactory.h"


int main() {
    std::unique_ptr<ICarFactory> carFactory = std::make_unique<MockEngineCarFactory>();

    // Create a Car object with automatic dependency injection
    std::unique_ptr<ICar> car = carFactory->CreateCar();

    // Start the car
    car->Start();

    // Stop the car
    car->Stop();

    return 0;
}

/*
- The dependency is now injected automatically by factory method.
- The pitfall of the new design is
  The same typed dependency is injected everytime.
- The factory method can be further templated to support various kinds of dependencies.
*/