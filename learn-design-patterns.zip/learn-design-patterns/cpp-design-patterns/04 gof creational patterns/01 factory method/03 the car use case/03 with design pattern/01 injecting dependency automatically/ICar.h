#pragma once

class ICar {
public:
	virtual ~ICar() = default;
public:
	virtual void Start() = 0;
	virtual void Stop() = 0;
};