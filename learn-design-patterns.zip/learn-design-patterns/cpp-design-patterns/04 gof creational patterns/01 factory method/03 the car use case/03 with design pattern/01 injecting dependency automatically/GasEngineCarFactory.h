#pragma once

#include <memory>

#include "ICar.h"
#include "ICarFactory.h"

class GasEngineCarFactory :
    public ICarFactory {
public:
    std::unique_ptr<ICar> CreateCar() override;
};