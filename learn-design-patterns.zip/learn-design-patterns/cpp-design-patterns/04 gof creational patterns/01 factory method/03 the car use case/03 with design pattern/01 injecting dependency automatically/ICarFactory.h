#pragma once

#include <memory>

#include "ICar.h"

class ICarFactory {
public:
	virtual ~ICarFactory() = default;
	virtual std::unique_ptr<ICar> CreateCar() = 0;
};