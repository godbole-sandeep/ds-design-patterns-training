#include <memory>
#include <type_traits>

#include "Car.h"
#include "ICar.h"
#include "IEngine.h"
#include "MockEngine.h"
#include "MockEngineCarFactory.h"

#include "MockEngineCarFactory.h"

std::unique_ptr<ICar> MockEngineCarFactory::CreateCar() {
	std::unique_ptr<IEngine> mockEngine = std::make_unique<MockEngine>();
	std::unique_ptr<ICar> car(std::make_unique<Car>(std::move(mockEngine)));
	return car;
}