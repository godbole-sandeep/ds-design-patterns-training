#include <memory>
#include <type_traits>

#include "Car.h"
#include "GasEngine.h"
#include "GasEngineCarFactory.h"
#include "ICar.h"
#include "IEngine.h"

std::unique_ptr<ICar> GasEngineCarFactory::CreateCar() {
	std::unique_ptr<IEngine> gasEngine = std::make_unique<GasEngine>();
	std::unique_ptr<ICar> car(std::make_unique<Car>(std::move(gasEngine)));
	return car;
}