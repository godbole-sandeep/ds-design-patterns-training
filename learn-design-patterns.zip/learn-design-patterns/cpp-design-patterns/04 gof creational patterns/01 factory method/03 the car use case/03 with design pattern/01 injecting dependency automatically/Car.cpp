#include <iostream>
#include <memory>
#include <type_traits>

#include "Car.h"
#include "IEngine.h"

Car::Car(std::unique_ptr<IEngine> engine)
	: m_engine(std::move(engine)) {}

void Car::Start() {
	m_engine->Start();
	std::cout << "Car started." << std::endl;
}

void Car::Stop() {
	std::cout << "Car stopped." << std::endl;
	m_engine->Stop();
}