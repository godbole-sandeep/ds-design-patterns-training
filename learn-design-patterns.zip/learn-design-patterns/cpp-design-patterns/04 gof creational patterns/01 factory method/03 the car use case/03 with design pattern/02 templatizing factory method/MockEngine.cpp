#include <iostream>

#include "MockEngine.h"

// Method to start the engine
void MockEngine::Start() {
    std::cout << "Mock engine started." << std::endl;
}

// Method to stop the engine
void MockEngine::Stop() {
    std::cout << "Mock engine stopped." << std::endl;
}