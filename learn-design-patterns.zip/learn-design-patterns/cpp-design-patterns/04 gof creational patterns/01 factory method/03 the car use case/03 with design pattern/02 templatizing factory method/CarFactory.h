#pragma once

#include <memory>
#include <type_traits>

#include "Car.h"
#include "ICar.h"
#include "ICarFactory.h"
#include "IEngine.h"

template<class EngineType>
class CarFactory :
	public ICarFactory {
public:
	std::unique_ptr<ICar> CreateCar() override {
		std::unique_ptr<ICar> car = std::make_unique<Car>(std::make_unique<EngineType>());
		return car;
	}
};