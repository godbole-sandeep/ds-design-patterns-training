#include <iostream>

#include "GasEngine.h"

// Method to start the engine
void GasEngine::Start() {
    std::cout << "Gas engine started." << std::endl;
}

// Method to stop the engine
void GasEngine::Stop() {
    std::cout << "Gas engine stopped." << std::endl;
}