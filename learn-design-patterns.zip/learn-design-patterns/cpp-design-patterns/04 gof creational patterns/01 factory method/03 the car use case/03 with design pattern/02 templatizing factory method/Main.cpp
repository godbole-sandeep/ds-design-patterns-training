#include <memory>

#include "CarFactory.h"
#include "GasEngine.h"
#include "ICar.h"
#include "ICarFactory.h"
#include "MockEngine.h"

int main() {
    // Create instance of gas engine car factory
    std::unique_ptr<ICarFactory> gasEngineCarFactory = std::make_unique<CarFactory<GasEngine>>();

    // Create a Car object
    auto gasCar = gasEngineCarFactory->CreateCar();

    // Start the car
    gasCar->Start();

    // Stop the car
    gasCar->Stop();

    // Create instance of mock engine car factory
    std::unique_ptr<ICarFactory> mockEngineCarFactory = std::make_unique<CarFactory<MockEngine>>();

    // Create a Car object
    auto mockCar = mockEngineCarFactory->CreateCar();

    // Start the car
    mockCar->Start();

    // Stop the car
    mockCar->Stop();

    return 0;
}

/*
- The dependency is now injected automatically by factory method.
- The factory method has been templated to support various kinds of dependencies.
*/