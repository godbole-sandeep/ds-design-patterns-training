#include <iostream>

#include "GasEngine.h"

void GasEngine::Start() {
    std::cout << "Gas engine started." << std::endl;
}

void GasEngine::Stop() {
    std::cout << "Gas engine stopped." << std::endl;
}