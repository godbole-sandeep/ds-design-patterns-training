#include <iostream>

#include <memory>
#include <new>
#include "Car.h"
#include "GasEngine.h"

Car::Car()
	: m_engine(new GasEngine()) {}

void Car::Start() {
	m_engine->Start();
	std::cout << "Car started." << std::endl;
}

void Car::Stop() {
	std::cout << "Car stopped." << std::endl;
	m_engine->Stop();
}