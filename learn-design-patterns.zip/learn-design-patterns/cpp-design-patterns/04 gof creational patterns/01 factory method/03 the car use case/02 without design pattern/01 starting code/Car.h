#pragma once

#include <memory>

#include "GasEngine.h"

class Car {
public:
    Car();
public:
    void Start();
    void Stop();
private:
    std::unique_ptr<GasEngine> m_engine;
};