#pragma once

class GasEngine {
public:
    void Start();
    void Stop();
};