#include "Car.h"

int main() {
    // Create a car object
    Car car;

    // Start the car
    car.Start();

    // Stop the car
    car.Stop();

    return 0;
}

/*
- Pitfalls of the above design:
  1. Car class is not testable.
     For the Car object to be testable, the Engine object must be present.
  2. Code is not extensible.
     To replace GasEngine with the MockEngine object, a class code change is required.
  3. Violation of Single Responsibility Principle.
     The Car class, in addition to handling car operations, also assumes the responsibility
     of instantiating an Engine object.
  4. Missing reusability.
     Each Car object requires its own unique Engine instance and cannot share it with other Car objects.
*/