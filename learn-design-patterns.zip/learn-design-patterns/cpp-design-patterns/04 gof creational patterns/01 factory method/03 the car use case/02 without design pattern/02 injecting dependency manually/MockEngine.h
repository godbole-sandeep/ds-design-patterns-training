#pragma once

#include "IEngine.h"

class MockEngine
    : public IEngine {
public:
    void Start();
    void Stop();
};