#pragma once

#include "IEngine.h"

class GasEngine
    : public IEngine {
public:
    void Start();
    void Stop();
};