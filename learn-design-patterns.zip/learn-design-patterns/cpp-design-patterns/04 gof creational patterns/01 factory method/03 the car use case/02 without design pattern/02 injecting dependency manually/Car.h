#pragma once

#include <memory>

#include "IEngine.h"

class Car {
public:
    Car(std::unique_ptr<IEngine> engine);
public:
    void Start();
    void Stop();
private:
    std::unique_ptr<IEngine> m_engine;
};