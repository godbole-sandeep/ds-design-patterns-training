#include <memory>

#include "Car.h"
#include "GasEngine.h"
#include "IEngine.h"
#include "MockEngine.h"
#include <type_traits>

int main() {
    // Create a Car object with dependency injection
    // Car car(std::make_unique<GasEngine>());
    Car car(std::make_unique<MockEngine>());

    // Start the car
    car.Start();

    // Stop the car
    car.Stop();

    return 0;
}

/*
- Benefits of the above design:
  1. Car class is testable.
     The Car object can now be tested with a mock engine object instead of a GasEngine object.
  2. Code is extensible.
     The Car object can now be tested with a mock engine object without making any changes to the Car class.
  3. Adherence to the Single Responsibility Principle.
     The code now adheres to the Single Responsibility Principle.
     The responsibility of creating the engine has been removed from the car. 
     In other words, the creation logic and the business logic have been separated.
  4. Reusability is present.
     The Engine object can be shared among multiple Car objects.
- The pitfall of the new design is
  The dependencies are to be injected manually.
*/