#include <iostream>

#include "MockEngine.h"

void MockEngine::Start() {
    std::cout << "Mock engine started." << std::endl;
}

void MockEngine::Stop() {
    std::cout << "Mock engine stopped." << std::endl;
}