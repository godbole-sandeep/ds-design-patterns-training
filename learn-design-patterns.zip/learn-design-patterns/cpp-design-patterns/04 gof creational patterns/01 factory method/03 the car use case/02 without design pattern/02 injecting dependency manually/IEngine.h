#pragma once

class IEngine {
public:
    virtual ~IEngine() = default;
public:
    virtual void Start() = 0;
    virtual void Stop() = 0;
};