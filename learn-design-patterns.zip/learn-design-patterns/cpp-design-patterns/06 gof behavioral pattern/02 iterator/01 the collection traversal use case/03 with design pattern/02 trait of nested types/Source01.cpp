#include <iostream>

class A {
public:
	A(int value) : m_value(value) {}
private:
	int m_value;
};

class B {
public:
	B(A& a) : m_a(a) {}
public:
	void AccessAData() {
		std::cout << "Value of m_value: " << m_a.m_value << std::endl; // Error!
	}
private:
	A& m_a;
};

int main() {
	A a(42);
	B b(a);
	b.AccessAData();
	return 0;
}

/*
- Private members of class A are not accessible outside of class A.
*/