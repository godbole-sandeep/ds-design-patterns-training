#include <iostream>

class A {
public:
	class B {
	public:
		B(A& a) : m_a(a) {}
	public:
		void AccessAData() {
			std::cout << "Value of m_value: " << m_a.m_value << std::endl; // OK
		}
	private:
		A& m_a;
	};
public:
	A(int value) : m_value(value) {}
private:
	int m_value;
};


int main() {
	A a(42);
	A::B b(a);
	b.AccessAData();
	return 0;
}

/*
- Besides making class B a friend of class A, nesting class B within class A also
  gives access to the private members of class A.
*/