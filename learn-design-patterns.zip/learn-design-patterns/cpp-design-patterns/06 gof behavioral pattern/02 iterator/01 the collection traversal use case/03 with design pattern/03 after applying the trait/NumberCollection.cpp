#include <memory>
#include <stdexcept>

#include "NumberCollection.h"

NumberCollection::Iterator::Iterator(NumberCollection& collection) : m_collection(collection), m_current_index(0) {}

bool NumberCollection::Iterator::IsDone() {
	return m_current_index >= m_collection.m_numbers.size();
}

int& NumberCollection::Iterator::Item() {
	if (m_current_index < m_collection.m_numbers.size()) {
		return m_collection.m_numbers[m_current_index];
	}
	throw std::out_of_range("No item available during iteration");
}

void NumberCollection::Iterator::Next() {
	m_current_index++;
}

void NumberCollection::Iterator::Reset() {
	m_current_index = 0;
}

NumberCollection::NumberCollection(const std::vector<int>& numbers) : m_numbers(numbers) {}

std::unique_ptr<NumberCollection::Iterator> NumberCollection::GetIterator() {
	return std::make_unique<Iterator>(*this);
}