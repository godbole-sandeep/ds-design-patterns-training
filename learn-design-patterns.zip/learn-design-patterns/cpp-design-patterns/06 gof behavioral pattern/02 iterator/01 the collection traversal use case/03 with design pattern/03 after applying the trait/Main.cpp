#include <iostream>
#include <memory>

#include "NumberCollection.h"

int main() {
    // Create a collection of numbers
    std::vector<int> numbers = { 1, 5, 3, 7 };
    NumberCollection collection(numbers);

    std::unique_ptr<NumberCollection::Iterator> it = collection.GetIterator();

    // Iterate through the collection and print each element
    std::cout << "Collection: ";
    while (!it->IsDone()) {
        std::cout << it->Item() << " ";
        it->Next();
    }
    std::cout << std::endl;

    // Reset and iterate again
    it->Reset();
    std::cout << "Collection (after reset): ";
    while (!it->IsDone()) {
        std::cout << it->Item() << " ";
        it->Next();
    }
    std::cout << std::endl;

    return 0;
}
