#pragma once

#ifndef NUMBERCOLLECTION_H
#define NUMBERCOLLECTION_H

#include <memory>
#include <vector>

class NumberCollection {
public:
    class Iterator {
    public:
        Iterator(NumberCollection& collection);
    public:
        bool IsDone();
        int& Item();
        void Next();
        void Reset(); // Reset iterator to the beginning
    private:
        NumberCollection& m_collection;
        size_t m_current_index;
    };
public:
    NumberCollection(const std::vector<int>& numbers);
public:
    std::unique_ptr<Iterator> GetIterator();
private:
    std::vector<int> m_numbers;
};

#endif // NUMBERCOLLECTION_H