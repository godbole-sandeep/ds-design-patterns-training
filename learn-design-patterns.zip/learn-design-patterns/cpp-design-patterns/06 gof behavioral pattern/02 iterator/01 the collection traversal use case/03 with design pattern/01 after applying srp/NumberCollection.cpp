#include <stdexcept>

#include "NumberCollection.h"

NumberCollection::NumberCollection(const std::vector<int>& numbers) : m_numbers(numbers) {}