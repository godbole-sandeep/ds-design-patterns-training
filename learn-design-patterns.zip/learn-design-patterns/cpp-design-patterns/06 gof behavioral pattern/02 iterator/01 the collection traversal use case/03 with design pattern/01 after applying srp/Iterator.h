#pragma once

#include "NumberCollection.h"

class Iterator {
public:
    Iterator(NumberCollection& collection);
public:
    bool IsDone();
    int& Item();
    void Next();
    void Reset(); // Reset iterator to the beginning
private:
    NumberCollection& m_collection;
    size_t m_current_index;
};