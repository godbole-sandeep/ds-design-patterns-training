#pragma once

#include <vector>

class NumberCollection {
public:
	NumberCollection(const std::vector<int>& numbers);
private:
	std::vector<int> m_numbers;
	friend class Iterator;
};