#include <iostream>
#include <memory>

#include "Iterator.h"
#include "NumberCollection.h"

int main() {
    // Create a collection of numbers
    std::vector<int> numbers = { 1, 5, 3, 7 };
    NumberCollection collection(numbers);

    Iterator it(collection);

    // Iterate through the collection and print each element
    std::cout << "Collection: ";
    while (!it.IsDone()) {
        std::cout << it.Item() << " ";
        it.Next();
    }
    std::cout << std::endl;

    // Reset and iterate again
    it.Reset();
    std::cout << "Collection (after reset): ";
    while (!it.IsDone()) {
        std::cout << it.Item() << " ";
        it.Next();
    }
    std::cout << std::endl;

    return 0;
}

/*
- The biggest pitfall of this design is the potential for inconsistent data views
  if the same collection object is referred to from different locations for reading
  the data.
- Also it breaks SRP, since the object will have to manage data in the collection
  and traversal.
*/