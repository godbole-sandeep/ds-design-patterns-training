#include <stdexcept>

#include "Iterator.h"

Iterator::Iterator(NumberCollection& collection) : m_collection(collection), m_current_index(0) {}

bool Iterator::IsDone() {
	return m_current_index >= m_collection.m_numbers.size();
}

int& Iterator::Item() {
	if (m_current_index < m_collection.m_numbers.size()) {
		return m_collection.m_numbers[m_current_index];
	}
	throw std::out_of_range("No item available during traversal");
}

void Iterator::Next() {
	m_current_index++;
}

void Iterator::Reset() {
	m_current_index = 0;
}