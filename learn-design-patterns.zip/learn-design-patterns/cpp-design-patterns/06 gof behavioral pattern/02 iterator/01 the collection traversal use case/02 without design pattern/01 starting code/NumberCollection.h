#pragma once

#include <vector>

class NumberCollection {
public:
	NumberCollection(const std::vector<int>& numbers);
public:
	bool IsDone();
	int& Item();
	void Next();
	void Reset();
private:
	std::vector<int> m_numbers;
	size_t m_current_index;
};