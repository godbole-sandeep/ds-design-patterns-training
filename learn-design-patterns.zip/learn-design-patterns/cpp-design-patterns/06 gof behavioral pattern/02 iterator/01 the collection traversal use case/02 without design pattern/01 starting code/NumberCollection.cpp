#include <stdexcept>

#include "NumberCollection.h"

NumberCollection::NumberCollection(const std::vector<int>& numbers) : m_numbers(numbers), m_current_index(0) {}

bool NumberCollection::IsDone() {
	return m_current_index >= m_numbers.size();
}

int& NumberCollection::Item() {
	if (m_current_index < m_numbers.size()) {
		return m_numbers[m_current_index];
	}
	throw std::out_of_range("No item available during traversal");
}

void NumberCollection::Next() {
	m_current_index++;
}

void NumberCollection::Reset() {
	m_current_index = 0;
}