#include <iostream>

#include "CompositeElement.h"

CompositeElement::CompositeElement(const std::string& name) : m_name(name) {}

std::string CompositeElement::GetName() const { return m_name; }

void CompositeElement::AddChild(std::unique_ptr<IElement> child) {
	m_children.push_back(std::move(child));
}

void CompositeElement::GenerateXml() const {
	// Generate opening tag for CompositeElement
	std::cout << "<" << m_name << ">" << std::endl;

	// Generate XML for each child element
	for (const auto& child : m_children) {
		child->GenerateXml();
	}

	// Generate closing tag for CompositeElement
	std::cout << "</" << m_name << ">" << std::endl;
}