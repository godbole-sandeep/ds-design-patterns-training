#include <memory>

#include "CompositeElement.h"
#include "DataElement.h"

int main() {
	// Create Composite element
	std::unique_ptr<CompositeElement> composite = std::make_unique<CompositeElement>("person");

	// Create DataElements and add them to Composite element
	composite->AddChild(std::make_unique<DataElement>("name", "John"));
	composite->AddChild(std::make_unique<DataElement>("age", "30"));

	// Serialize to XML
	composite->GenerateXml();

	return 0;
}