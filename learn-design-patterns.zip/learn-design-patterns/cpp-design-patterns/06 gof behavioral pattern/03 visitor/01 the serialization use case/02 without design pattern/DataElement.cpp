#include <iostream>

#include "DataElement.h"

DataElement::DataElement(const std::string& name, const std::string& value) : m_name(name), m_value(value) {}

std::string DataElement::GetName() const { return m_name; }

void DataElement::GenerateXml() const {
	std::cout << "<" << m_name << ">" << m_value << "</" << m_name << ">" << std::endl;
}