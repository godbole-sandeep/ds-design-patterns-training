#pragma once

#include <string>

class IElement {
public:
	virtual ~IElement() = default;
public:
	virtual void GenerateXml() const = 0;
	virtual std::string GetName() const = 0;
};