#pragma once

#include <memory>
#include <vector>

#include "IElement.h"

class CompositeElement : public IElement {
public:
    CompositeElement(const std::string& name);
public:
    std::string GetName() const override;
public:
    void AddChild(std::unique_ptr<IElement> child);
    void GenerateXml() const override;
private:
    std::string m_name;
    std::vector<std::unique_ptr<IElement>> m_children;
};