#include "CompositeElement.h"

CompositeElement::CompositeElement(const std::string& name) : m_name(name) {}

const std::string& CompositeElement::GetName() const {
	return m_name;
}

const std::vector<std::unique_ptr<IElement>>& CompositeElement::GetChildren() const {
	return m_children;
}

void CompositeElement::AddChild(std::unique_ptr<IElement> child) {
	m_children.push_back(std::move(child));
}

void CompositeElement::Accept(const ISerializer* visitor) const {
	visitor->VisitComposite(*this);
}