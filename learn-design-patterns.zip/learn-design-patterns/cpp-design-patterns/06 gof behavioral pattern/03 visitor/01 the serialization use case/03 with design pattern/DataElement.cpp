#include "DataElement.h"
#include "ISerializer.h"

DataElement::DataElement(const std::string& n, const std::string& v) : m_name(n), m_value(v) {}

const std::string& DataElement::GetName() const { return m_name; }

const std::string& DataElement::GetValue() const { return m_value; }

void DataElement::Accept(const ISerializer* visitor) const {
	visitor->VisitData(*this);
}