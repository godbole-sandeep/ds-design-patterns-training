#include <memory>

#include "CompositeElement.h"
#include "DataElement.h"
#include "XmlSerializer.h"

int main() {
	// Create elements
	std::unique_ptr<DataElement> data1 = std::make_unique<DataElement>("name", "John");
	std::unique_ptr<DataElement> data2 = std::make_unique<DataElement>("age", "30");

	std::unique_ptr<CompositeElement> composite = std::make_unique<CompositeElement>("person");
	composite->AddChild(std::move(data1));
	composite->AddChild(std::move(data2));

	// Serialize to XML using visitor
	XmlSerializer serializer;
	composite->Accept(&serializer);

	return 0;
}