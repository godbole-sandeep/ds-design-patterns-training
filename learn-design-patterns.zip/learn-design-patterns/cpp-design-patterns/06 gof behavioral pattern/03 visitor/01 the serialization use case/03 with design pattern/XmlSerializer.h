#pragma once

#include "ISerializer.h"

class XmlSerializer : public ISerializer {
public:
	void VisitData(const DataElement& element) const override;
	void VisitComposite(const CompositeElement& element) const override;
};