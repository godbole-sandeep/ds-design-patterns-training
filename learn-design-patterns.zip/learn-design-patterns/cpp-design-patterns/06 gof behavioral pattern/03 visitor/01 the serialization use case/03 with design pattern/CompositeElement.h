#pragma once

#include <memory>
#include <string>
#include <vector>

#include "IElement.h"
#include "ISerializer.h"

class CompositeElement : public IElement {
public:
    CompositeElement(const std::string& name);
public:
    const std::string& GetName() const;
    const std::vector<std::unique_ptr<IElement>>& GetChildren() const;
public:
    void AddChild(std::unique_ptr<IElement> child);
    void Accept(const ISerializer* visitor) const override;
private:
    std::string m_name;
    std::vector<std::unique_ptr<IElement>> m_children;
};