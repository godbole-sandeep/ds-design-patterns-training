#include <iostream>

#include "CompositeElement.h"
#include "DataElement.h"
#include "XmlSerializer.h"

void XmlSerializer::VisitData(const DataElement& element) const {
    // Generate XML for DataElement
    std::cout << "<" << element.GetName() << ">" << element.GetValue() << "</" << element.GetName() << ">" << std::endl;
}

void XmlSerializer::VisitComposite(const CompositeElement& element) const {
    // Generate opening tag for CompositeElement
    std::cout << "<" << element.GetName() << ">" << std::endl;

    // Visit each child element
    for (const auto& child : element.GetChildren()) {
        child->Accept(this);
    }

    // Generate closing tag for CompositeElement
    std::cout << "</" << element.GetName() << ">" << std::endl;
}