#pragma once

class DataElement;
class CompositeElement;

class ISerializer {
public:
	~ISerializer() = default;
	virtual void VisitData(const DataElement& element) const = 0;
	virtual void VisitComposite(const CompositeElement& element) const = 0;
};