#pragma once

class ISerializer;

class IElement {
public:
    virtual ~IElement() = default;
    virtual void Accept(const ISerializer* visitor) const = 0;
};