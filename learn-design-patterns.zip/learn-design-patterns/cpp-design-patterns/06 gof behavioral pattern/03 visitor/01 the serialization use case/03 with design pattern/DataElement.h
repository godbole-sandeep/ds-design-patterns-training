#pragma once

#include <string>

#include "IElement.h"

class DataElement : public IElement {
public:
    DataElement(const std::string& n, const std::string& v);
public:
    const std::string& GetName() const;
    const std::string& GetValue() const;
public:
    void Accept(const ISerializer* visitor) const override;
private:
    std::string m_name;
    std::string m_value;
};