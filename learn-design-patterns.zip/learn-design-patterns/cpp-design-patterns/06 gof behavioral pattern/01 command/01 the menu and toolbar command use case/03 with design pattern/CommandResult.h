#pragma once

#ifndef COMMANDRESULT_H
#define COMMANDRESULT_H

#include <string>

class CommandResult {
public:
    CommandResult(int errorNo, const std::string& errorMessage);
public:
    int errorNo;
    std::string errorMessage;
};

#endif