#include "CommandResult.h"

CommandResult::CommandResult(int errorNo, const std::string& errorMessage = "")
    : errorNo(errorNo), errorMessage(errorMessage) {}