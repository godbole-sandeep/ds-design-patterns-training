#include <fstream>
#include <iostream>
#include <sstream>
#include <winerror.h>

#include "OpenFileCommand.h"
#include "Point.h"

Point point{ 0, 0 };

CommandResult mnuFileOpen_Click() {
	OpenFileCommand openFileCmdObj(point);
	openFileCmdObj.Execute();
	return openFileCmdObj.Reult();
}

CommandResult tlbFileOpen_Click() {
	OpenFileCommand openFileCmdObj(point);
	openFileCmdObj.Execute();
	return openFileCmdObj.Reult();
}

int main() {
	// Consider calling 'mnuFileOpen_Click' as equivalent to the user
	// clicking on the File > Open... menu item.
	CommandResult cmdResult = mnuFileOpen_Click();
	switch (cmdResult.errorNo) {
	case ERROR_SUCCESS:
		std::cout << cmdResult.errorMessage << std::endl;
		std::cout << "X: " << point.x << ", Y: " << point.y << std::endl;
		break;
	case ERROR_FILE_NOT_FOUND:
		std::cerr << cmdResult.errorMessage << std::endl;
		break;
	case ERROR_BAD_FORMAT:
		std::cerr << cmdResult.errorMessage << std::endl;
		break;
	}
	return 0;
}

/*
- The procedure 'mnuFileOpen_Click' is invoked when the user clicks the File > Open... menu item.
- The procedure 'tlbFileOpen_Click' is invoked when the user clicks the Open toolbar button.
*/