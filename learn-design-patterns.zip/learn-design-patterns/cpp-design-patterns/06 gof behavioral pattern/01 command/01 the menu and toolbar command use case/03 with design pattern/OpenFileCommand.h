#pragma once

#ifndef OPENFILECOMMAND_H
#define OPENFILECOMMAND_H

#include "Command.h"
#include "CommandResult.h"
#include "Point.h"

class OpenFileCommand : public Command {
public:
	OpenFileCommand(Point& pointRef);
public:
	void Execute() override;
	CommandResult Reult();
private:
	Point& m_pointRef;
	CommandResult m_commandResult;
};

#endif