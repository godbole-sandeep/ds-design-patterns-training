#include <fstream>
#include <iostream>
#include <sstream>
#include <winerror.h>

#include "OpenFileCommand.h"

OpenFileCommand::OpenFileCommand(Point& pointRef)
	: m_pointRef(pointRef), m_commandResult(0, "Success") {}

void OpenFileCommand::Execute() {
	// Accept the filename from the user
	std::string filename;
	std::cout << "Enter file name: ";
	std::getline(std::cin, filename);

	// Attempt to open the file or report an error if it fails.
	std::ifstream file(filename);
	if (!file.is_open()) {
		m_commandResult.errorNo = ERROR_FILE_NOT_FOUND;
		m_commandResult.errorMessage = "Error: Could not open file " + filename;
		return;
	}

	// Read the first line (assuming the format is on one line)
	std::string line;
	std::getline(file, line);

	// Set up the object or report an error if it fails
	std::istringstream iss(line);
	if (!(iss >> m_pointRef.x >> m_pointRef.y)) {
		m_commandResult.errorNo = ERROR_BAD_FORMAT;
		m_commandResult.errorMessage = "Error: Invalid data format in file " + filename;
		return;
	}

	file.close();

	m_commandResult.errorNo = ERROR_SUCCESS;
	m_commandResult.errorMessage = "Point data read successfully!";
}

CommandResult OpenFileCommand::Reult() {
	return m_commandResult;
}