#include <fstream>
#include <iostream>
#include <sstream>
#include <winerror.h>

struct Point {
	double x;
	double y;
};

Point point{ 0, 0 };

int mnuFileOpen_Click() {
	// Accept the filename from the user
	std::string filename;
	std::cout << "Enter file name: ";
	std::getline(std::cin, filename);

	// Attempt to open the file or report an error if it fails.
	std::ifstream file(filename);
	if (!file.is_open()) {
		return ERROR_FILE_NOT_FOUND;
	}

	// Read the first line (assuming the format is on one line)
	std::string line;
	std::getline(file, line);

	// Set up the object or report an error if it fails
	std::istringstream iss(line);
	if (!(iss >> point.x >> point.y)) {
		return ERROR_BAD_FORMAT;
	}

	file.close();

	return ERROR_SUCCESS;
}

int tlbFileOpen_Click() {
	// Accept the filename from the user
	std::string filename;
	std::cout << "Enter file name: ";
	std::getline(std::cin, filename);

	// Attempt to open the file or report an error if it fails.
	std::ifstream file(filename);
	if (!file.is_open()) {
		return ERROR_FILE_NOT_FOUND;
	}

	// Read the first line (assuming the format is on one line)
	std::string line;
	std::getline(file, line);

	// Set up the object or report an error if it fails
	std::istringstream iss(line);
	if (!(iss >> point.x >> point.y)) {
		return ERROR_BAD_FORMAT;
	}

	file.close();

	return ERROR_SUCCESS;
}

int main() {
	// Consider calling 'mnuFileOpen_Click' as equivalent to the user
	// clicking on the File > Open... menu item.
	int err = mnuFileOpen_Click();
	switch (err) {
	case ERROR_SUCCESS:
		std::cout << "Point data read successfully!" << std::endl;
		std::cout << "X: " << point.x << ", Y: " << point.y << std::endl;
		break;
	case ERROR_FILE_NOT_FOUND:
		std::cerr << "Error: Could not open file " << std::endl;
		break;
	case ERROR_BAD_FORMAT:
		std::cerr << "Error: Invalid data format in file " << std::endl;
		break;
	}
	return 0;
}

/*
- The procedure 'mnuFileOpen_Click' is invoked when the user clicks the File > Open... menu item.
- The procedure 'tlbFileOpen_Click' is invoked when the user clicks the Open toolbar button.
*/