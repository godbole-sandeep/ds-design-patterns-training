#include <iostream>
#include <memory>
#include <vector>

// Interface for all shapes (base class)
class Shape {
public:
    virtual ~Shape() = default;
    virtual void Draw() const = 0;
};

// Concrete classes for basic shapes (leaves in the composite pattern)
class Line : public Shape {
public:
    void Draw() const override {
        std::cout << "Drawing a line..." << std::endl;
    }
};

class Rectangle : public Shape {
public:
    void Draw() const override {
        std::cout << "Drawing a rectangle..." << std::endl;
    }
};

class Oval : public Shape {
public:
    void Draw() const override {
        std::cout << "Drawing an oval..." << std::endl;
    }
};

// Composite class for grouping shapes
class Group : public Shape {
public:
    void AddShape(std::unique_ptr<Shape> shape) {
        shapes.push_back(std::move(shape));
    }

    void Draw() const override {
        std::cout << "Drawing a group of shapes:" << std::endl;
        for (const auto& shape : shapes) {
            shape->Draw();
        }
    }
private:
    std::vector<std::unique_ptr<Shape>> shapes;
};

int main() {
    // Create a top-level group
    std::unique_ptr <Group> group1Ptr = std::make_unique<Group>();

    // Add basic shapes to the group
    group1Ptr->AddShape(std::make_unique<Line>());
    group1Ptr->AddShape(std::make_unique<Rectangle>());
    group1Ptr->AddShape(std::make_unique<Oval>());

    // Draw the top-level group
    group1Ptr->Draw();

    // Create another group
    std::unique_ptr <Group> group2Ptr = std::make_unique<Group>();

    // Add line to another group
    group2Ptr->AddShape(std::make_unique<Line>());

    // Add another group to top-level group (nesting)
    group1Ptr->AddShape(std::move(group2Ptr));

    // Draw the top-level group
    group1Ptr->Draw();

    return 0;
}