#pragma once

#ifndef PERSON_H
#define PERSON_H

#include <memory>
#include <string>

#include "Serializer.h"

class Person {
public:
    Person(const std::string& name, int age);
    virtual ~Person() = default;
public:
    const std::string& GetName() const;
    int GetAge() const;
    void SetSerializer(std::shared_ptr<Serializer> serializerPtr);
public:
    virtual void Save() const;
protected:
    std::shared_ptr<Serializer> m_serializerPtr;
private:
    std::string m_name;
    int m_age;
};

#endif // PERSON_H