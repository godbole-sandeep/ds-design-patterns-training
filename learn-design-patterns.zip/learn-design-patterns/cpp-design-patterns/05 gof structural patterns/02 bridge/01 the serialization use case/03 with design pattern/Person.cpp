#include <iostream>

#include "person.h"

Person::Person(const std::string& name, int age) : m_name(name), m_age(age) {}

const std::string& Person::GetName() const {
    return m_name;
}

int Person::GetAge() const {
    return m_age;
}

void Person::SetSerializer(std::shared_ptr<Serializer> serializerPtr) {
    m_serializerPtr = serializerPtr;
}

void Person::Save() const {
    m_serializerPtr->WriteBanner();
    m_serializerPtr->WriteString("Name: ", m_name);
    m_serializerPtr->WriteInt("Age: ", m_age);
}