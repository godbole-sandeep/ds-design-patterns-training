#pragma once

#ifndef DBSERIALIZER_H
#define DBSERIALIZER_H

#include "Serializer.h"

class DbSerializer :
    public Serializer {
public:
    void WriteBanner() override;
    void WriteInt(const char* propertyName, int value) override;
    void WriteString(const char* propertyName, const std::string& value) override;
};

#endif