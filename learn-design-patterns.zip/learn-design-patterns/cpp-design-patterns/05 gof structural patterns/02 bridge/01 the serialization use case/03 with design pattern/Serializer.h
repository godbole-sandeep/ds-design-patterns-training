#pragma once

#ifndef SERIALIZER_H
#define SERIALIZER_H

#include <string>

class Serializer {
public:
	virtual ~Serializer() = default;
public:
	virtual void WriteBanner() = 0;
	virtual void WriteInt(const char* propertyName, int value) = 0;
	virtual void WriteString(const char* propertyName, const std::string& value) = 0;
};

#endif