#include <iostream>

#include "DbSerializer.h"

void DbSerializer::WriteBanner() {
	std::cout << "The following object's record is stored in the database." << std::endl;
}

void DbSerializer::WriteInt(const char* propertyName, int value) {
	std::cout << propertyName << value << std::endl;
}

void DbSerializer::WriteString(const char* propertyName, const std::string& value) {
	std::cout << propertyName << value << std::endl;
}