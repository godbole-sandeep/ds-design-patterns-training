#pragma once

#ifndef FILESERIALIZER_H
#define FILESERIALIZER_H

#include "Serializer.h"

class FileSerializer :
	public Serializer {
public:
	void WriteBanner() override;
	void WriteInt(const char* propertyName, int value) override;
	void WriteString(const char* propertyName, const std::string& value) override;
};

#endif