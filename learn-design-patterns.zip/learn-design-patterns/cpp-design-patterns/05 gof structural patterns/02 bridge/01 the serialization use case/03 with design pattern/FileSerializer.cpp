#include <iostream>

#include "FileSerializer.h"

void FileSerializer::WriteBanner() {
	std::cout << "The following object's record is stored in the file." << std::endl;
}

void FileSerializer::WriteInt(const char* propertyName, int value) {
	std::cout << propertyName << value << std::endl;
}

void FileSerializer::WriteString(const char* propertyName, const std::string& value) {
	std::cout << propertyName << value << std::endl;
}