#include "DbSerializer.h"
#include "FileSerializer.h"
#include "Person.h"
#include "Student.h"

int main() {
    // Create DbSerializer object
    std::shared_ptr<DbSerializer> dbSerializerPtr = std::make_shared<DbSerializer>();

    // Create FileSerializer object
    std::shared_ptr<FileSerializer> fileSerializerPtr = std::make_shared<FileSerializer>();
    
    // Create a Person object
    Person person("Smita", 30);

    // Serialize to database
    person.SetSerializer(dbSerializerPtr);

    // Save person's data to database
    person.Save();

    // Serialize to file
    person.SetSerializer(fileSerializerPtr);

    // Save person's data to file
    person.Save();

    // Create a Student object
    Student student("Mukund", 25, 12345);

    // Serialize to database
    student.SetSerializer(dbSerializerPtr);

    // Save student's data to database
    student.Save();

    // Serialize to file
    student.SetSerializer(fileSerializerPtr);

    // Save student's data to file
    student.Save();

    return 0;
}
