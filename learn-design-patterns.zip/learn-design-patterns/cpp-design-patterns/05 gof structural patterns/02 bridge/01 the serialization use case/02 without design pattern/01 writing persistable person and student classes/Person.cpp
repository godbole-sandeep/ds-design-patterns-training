#include <iostream>

#include "person.h"

Person::Person(const std::string& name, int age) : m_name(name), m_age(age) {}

const std::string& Person::GetName() const {
    return m_name;
}

int Person::GetAge() const {
    return m_age;
}

void Person::Save() const {
    std::cout << "The following person's record is stored in the file." << std::endl;
    std::cout << "Name: " << m_name << ", Age: " << m_age << std::endl;
}