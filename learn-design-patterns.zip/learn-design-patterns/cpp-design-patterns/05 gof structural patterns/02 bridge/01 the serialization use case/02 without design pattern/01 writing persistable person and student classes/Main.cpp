#include "Person.h"
#include "Student.h"

int main() {
    // Create a Person object
    Person person("Smita", 30);

    // Save person's data to file
    person.Save();

    // Create a Student object
    Student student("Mukund", 25, 12345);

    // Save student's data to file
    student.Save();

    return 0;
}

/*
- The code presents serious violation of SRP.
*/