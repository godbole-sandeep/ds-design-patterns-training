#include <iostream>

#include "DbSerializedStudent.h"

DbSerializedStudent::DbSerializedStudent(const std::string& name, int age, int studentID)
	: Student(name, age, studentID) {}

void DbSerializedStudent::Save() const {
	std::cout << "The following student's record is stored in the database." << std::endl;
	std::cout << "Name: " << GetName() << ", Age: " << GetAge() << ", Student ID: " << GetStudentID() << ", ";
}