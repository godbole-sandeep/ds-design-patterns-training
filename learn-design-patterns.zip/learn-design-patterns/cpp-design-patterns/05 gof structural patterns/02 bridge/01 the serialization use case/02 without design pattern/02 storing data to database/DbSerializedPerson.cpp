#include <iostream>

#include "DbSerializedPerson.h"

DbSerializedPerson::DbSerializedPerson(const std::string& name, int age)
	: Person(name, age) {}

void DbSerializedPerson::Save() const {
	std::cout << "The following person's record is stored in the database." << std::endl;
	std::cout << "Name: " << GetName() << ", Age: " << GetAge() << std::endl;
}