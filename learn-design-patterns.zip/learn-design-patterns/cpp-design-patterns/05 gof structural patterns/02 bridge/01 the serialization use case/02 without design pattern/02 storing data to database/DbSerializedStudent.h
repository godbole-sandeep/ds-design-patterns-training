#pragma once

#ifndef DBSERIALIZEDSTUDENT_H
#define DBSERIALIZEDSTUDENT_H

#include "Student.h"

class DbSerializedStudent
	: public Student {
public:
	DbSerializedStudent(const std::string& name, int age, int studentID);
public:
	void Save() const override;
};

#endif