#include <iostream>
#include <memory>

#include "ISubject.h"
#include "Logger.h"
#include "RealSubject.h"

int main() {
	std::unique_ptr<ISubject> realSubjectPtr = std::make_unique<RealSubject>();

	Logger::Log("Logging: Call to DoSomething");
	realSubjectPtr->DoSomething();

	Logger::Log("Logging: Call to DoSomething");
	realSubjectPtr->DoSomething();

	return 0;
}

/*
- The issue with this code is that the developer may miss logging some calls to RealSubject::DoSomething.
*/