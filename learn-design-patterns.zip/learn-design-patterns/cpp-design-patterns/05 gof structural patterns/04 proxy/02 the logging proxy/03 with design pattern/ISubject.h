#pragma once

#ifndef ISUBJECT_H
#define ISUBJECT_H

class ISubject {
public:
	virtual void DoSomething(const std::string& message) const = 0;
};

#endif // ISUBJECT_H