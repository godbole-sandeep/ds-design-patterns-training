#include <iostream>

#include "LoggingProxy.h"

LoggingProxy::LoggingProxy(std::unique_ptr<ISubject> realSubjectPtr) :
	m_realSubjectPtr(std::move(realSubjectPtr)) {}

void LoggingProxy::DoSomething(const std::string& message) const {
	// Log the message before forwarding the call to the real subject
	std::cout << "Logging: " << message << std::endl;
	m_realSubjectPtr->DoSomething(message);
}