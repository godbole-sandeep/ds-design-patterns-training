#pragma once

#ifndef LOGGINGPROXY_H
#define LOGGINGPROXY_H

#include <string>

#include "ISubject.h"

class LoggingProxy : public ISubject {
public:
	LoggingProxy(std::unique_ptr<ISubject> realSubjectPtr);
public:
	void DoSomething(const std::string& message) const override;
private:
	std::unique_ptr<ISubject> m_realSubjectPtr;
};

#endif // LOGGINGPROXY_H