#pragma once

#ifndef RECTANGLE_H
#define RECTANGLE_H

#include "GeometricObject.h"

class Rectangle : public GeometricObject {
public:
    void Draw() override;
};

#endif
