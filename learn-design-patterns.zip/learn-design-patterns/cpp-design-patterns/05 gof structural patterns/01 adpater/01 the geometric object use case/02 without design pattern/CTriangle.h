#pragma once

#ifndef CTRIANGLE_H
#define CTRIANGLE_H

class CTriangle {
public:
    void Show();
};

#endif