#include <memory>

#include "CTriangle.h"
#include "GeometricObject.h"
#include "Oval.h"
#include "Rectangle.h"

void Draw(std::shared_ptr<GeometricObject> geometricObject) {
    geometricObject->Draw();
}

void Draw(std::shared_ptr<CTriangle> triangle) {
    triangle->Show();
}

int main() {
    std::shared_ptr<GeometricObject> rectangle = std::make_shared<Rectangle>();
    std::shared_ptr<GeometricObject> oval = std::make_shared<Oval>();
    std::shared_ptr<CTriangle> triangle = std::make_shared<CTriangle>();

    Draw(rectangle);
    Draw(oval);
    Draw(triangle);

    return 0;
}

/*
- Though the solution is working, it has few drawbacks.
- Having multiple global Draw functions for different types introduces redundancy and can
  lead to maintenance issues.
- Ideally, a single polymorphic function should handle all drawable objects.
- A unified collection of GeometricObjects cannot be maintained as some classes may not be
  derived from GeometricObject class.
- The solution in this case is to use Adapter pattern.
*/