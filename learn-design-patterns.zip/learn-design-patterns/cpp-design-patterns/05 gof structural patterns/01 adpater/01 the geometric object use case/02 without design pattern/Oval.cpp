#include <iostream>

#include "Oval.h"

void Oval::Draw() {
	std::cout << "Drawing an oval." << std::endl;
}