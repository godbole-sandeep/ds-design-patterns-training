#pragma once

#ifndef OVAL_H
#define OVAL_H

#include "GeometricObject.h"

class Oval : public GeometricObject {
public:
    void Draw() override;
};

#endif