#pragma once

#ifndef TRIANGLE_H
#define TRIANGLE_H

#include <memory>

#include "CTriangle.h"
#include "GeometricObject.h"

class Triangle
	: public GeometricObject {
public:
	Triangle();
public:
	void Draw() override;
private:
	std::unique_ptr<CTriangle> m_trianglePtr;
};

#endif