#include <cassert>

#include "Triangle.h"

Triangle::Triangle()
	: m_trianglePtr(std::make_unique<CTriangle>()) {}

void Triangle::Draw() {
	assert(m_trianglePtr != nullptr);
	m_trianglePtr->Show();
}