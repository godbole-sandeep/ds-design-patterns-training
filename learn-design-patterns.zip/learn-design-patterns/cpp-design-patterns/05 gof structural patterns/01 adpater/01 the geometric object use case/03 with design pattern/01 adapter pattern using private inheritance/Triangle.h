#pragma once

#ifndef TRIANGLE_H
#define TRIANGLE_H

#include <memory>

#include "CTriangle.h"
#include "GeometricObject.h"

class Triangle
	: public GeometricObject, private CTriangle {
public:
	void Draw() override;
};

#endif