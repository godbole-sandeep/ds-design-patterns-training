#include "Triangle.h"

void Triangle::Draw() {
	Show();
}