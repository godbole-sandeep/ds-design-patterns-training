#include <assert.h>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>

class Integer {
public:
	Integer(int i);
public:
	int GetInteger() const;
private:
	int m_i;
};

Integer::Integer(int i) : m_i(i) {}

int Integer::GetInteger() const {
	return m_i;
}

class IFormatter {
public:
	virtual std::string Format() = 0;
};

class StringFormatter : public IFormatter {
public:
	StringFormatter(const Integer& obj);
public:
	virtual std::string Format();
private:
	const Integer& m_integer;
};

StringFormatter::StringFormatter(const Integer& obj) : m_integer(obj) {}

std::string StringFormatter::Format() {
	std::stringstream ss;
	ss << "m_i = " << m_integer.GetInteger();
	return ss.str();
}

class HTMLFormatter : public IFormatter {
public:
	HTMLFormatter(const Integer& obj);
public:
	virtual std::string Format();
private:
	const Integer& m_integer;
};

HTMLFormatter::HTMLFormatter(const Integer& obj) : m_integer(obj) {}

std::string HTMLFormatter::Format() {
	std::stringstream ss;
	ss << "<html><body><b>m_i</b> = " << m_integer.GetInteger() << "</body></html>";
	return ss.str();
}

class XMLFormatter : public IFormatter {
public:
	XMLFormatter(const Integer& obj);
public:
	virtual std::string Format();
private:
	const Integer& m_integer;
};

XMLFormatter::XMLFormatter(const Integer& obj) : m_integer(obj) {}

std::string XMLFormatter::Format() {
	std::stringstream ss;
	ss << "<?xml version=\"1.0\" encoding=\"utf-8\"?><data><m_i>"
		<< m_integer.GetInteger()
		<< "</m_i></data>";
	return ss.str();
}

std::string ReadFromFile(const std::string& fileName) {
	std::ifstream fin(fileName);
	std::stringstream ss;
	ss << fin.rdbuf();
	fin.close();
	return ss.str();
}

void WriteToFile(IFormatter& formatter, std::string pOutputFileName) {
	std::ofstream fout(pOutputFileName);
	fout << formatter.Format();
	fout.close();
}

void RunTests() {
	// Test Case 1: StringFormatter::Format with positive integer
	Integer pos(5);
	StringFormatter stringFormatter(pos);
	assert(stringFormatter.Format() == "m_i = 5");

	// Test Case 2: HTMLFormatter::Format with positive integer
	HTMLFormatter htmlFormatter(pos);
	assert(htmlFormatter.Format() == "<html><body><b>m_i</b> = 5</body></html>");

	// Test Case 3: XMLFormatter::Format with positive integer
	XMLFormatter xmlFormatter(pos);
	assert(xmlFormatter.Format() == "<?xml version=\"1.0\" encoding=\"utf-8\"?><data><m_i>5</m_i></data>");

	// Test Case 4: WriteToFile with StringFormatter
	WriteToFile(stringFormatter, "integer.txt");
	assert(ReadFromFile("integer.txt") == "m_i = 5");

	// Test Case 5: WriteToFile with HTMLFormatter
	WriteToFile(htmlFormatter, "integer.html");
	assert(ReadFromFile("integer.html") == "<html><body><b>m_i</b> = 5</body></html>");

	// Test Case 6: WriteToFile with XMLFormatter
	WriteToFile(xmlFormatter, "integer.xml");
	assert(ReadFromFile("integer.xml") == "<?xml version=\"1.0\" encoding=\"utf-8\"?><data><m_i>5</m_i></data>");
}

int main() {
	RunTests();
	std::cout << "All tests passed!" << std::endl;
	return 0;
}

/*
- Now each of the classes honors the Single Responsibility Principle (SRP) and
  the Open/Closed Principle (OCP).
- Why is constructor dependency injection used with formatter classes?
- If the dependency were injected through the formatter's 'Format' method,
  it would create tight coupling between the 'Integer' class and the
  'IFormatter' interface.
*/