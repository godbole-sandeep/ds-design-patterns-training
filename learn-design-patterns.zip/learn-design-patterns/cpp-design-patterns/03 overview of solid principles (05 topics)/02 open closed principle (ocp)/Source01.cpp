/*
- The user of the Format class requested that, in addition to converting integer
  to string and HTML, it should also convert to XML.
*/

#include <assert.h>
#include <iostream>
#include <sstream>
#include <string>

class Integer {
public:
	Integer(int i);
public:
	int GetInteger() const;
private:
	int m_i;
};

Integer::Integer(int i) : m_i(i) {}

int Integer::GetInteger() const { return m_i; }

class Format {
public:
	static std::string ToString(const Integer& obj);
	static std::string ToHTML(const Integer& obj);
	static std::string ToXML(const Integer& obj);
};

std::string Format::ToString(const Integer& obj) {
	std::stringstream ss;
	ss << "m_i = " << obj.GetInteger();
	return ss.str();
}

std::string Format::ToHTML(const Integer& obj) {
	std::stringstream ss;
	ss << "<html><body><b>m_i</b> = " << obj.GetInteger() << "</body></html>";
	return ss.str();
}

std::string Format::ToXML(const Integer& obj) {
	std::stringstream ss;
	ss << "<?xml version=\"1.0\" encoding=\"utf-8\"?><data><m_i>" << obj.GetInteger() << "</m_i></data>";
	return ss.str();
}

void RunTests() {
	// Test Case 1: ToString() with positive integer
	Integer pos(5);
	assert(Format::ToString(pos) == "m_i = 5");
	assert(pos.GetInteger() == 5);

	// Test Case 2: ToString() with negative integer
	Integer neg(-10);
	assert(Format::ToString(neg) == "m_i = -10");
	assert(neg.GetInteger() == -10);

	// Test Case 3: ToString() with zero
	Integer zero(0);
	assert(Format::ToString(zero) == "m_i = 0");
	assert(zero.GetInteger() == 0);

	// Test Case 4: ToHTML() with positive integer
	assert(Format::ToHTML(pos) == "<html><body><b>m_i</b> = 5</body></html>");

	// Test Case 5: ToHTML() with negative integer
	assert(Format::ToHTML(neg) == "<html><body><b>m_i</b> = -10</body></html>");

	// Test Case 6: ToHTML() with zero
	assert(Format::ToHTML(zero) == "<html><body><b>m_i</b> = 0</body></html>");

	// Test Case 7: Format::ToXML() with positive integer
	assert(Format::ToXML(pos) == "<?xml version=\"1.0\" encoding=\"utf-8\"?><data><m_i>5</m_i></data>");

	// Test Case 8: Format::ToXML() with negative integer
	assert(Format::ToXML(neg) == "<?xml version=\"1.0\" encoding=\"utf-8\"?><data><m_i>-10</m_i></data>");

	// Test Case 9: Format::ToXML() with zero
	assert(Format::ToXML(zero) == "<?xml version=\"1.0\" encoding=\"utf-8\"?><data><m_i>0</m_i></data>");
}

int main() {
	RunTests();
	std::cout << "All tests passed!" << std::endl;
	return 0;
}

/*
- The user of the Format class requested that, in addition to converting integers
  to strings and HTML, it should also convert to XML.
- Therefore, the author of the Format class had to modify the class.
- This is clear violation of Open Closed Principle (OCP).
- The OCP states that objects or entities should be open for extension but
  closed for modification.
*/