/*
- The user of the Integer class requested that integers be converted to HTML.
*/

#include <assert.h>
#include <iostream>
#include <sstream>
#include <string>

class Integer {
public:
	Integer(int i);
public:
	int GetInteger() const;
public:
	std::string ToString() const;
	std::string ToHTML() const;
private:
	int m_i;
};

Integer::Integer(int i) : m_i(i) {}

int Integer::GetInteger() const {
	return m_i;
}

std::string Integer::ToString() const {
	std::stringstream ss;
	ss << "m_i = " << m_i;
	return ss.str();
}

std::string Integer::ToHTML() const {
	std::stringstream ss;
	ss << "<html><body><b>m_i</b> = " << m_i << "</body></html>";
	return ss.str();
}

void RunTests() {
	// Test Case 1: ToString() with positive integer
	Integer pos(5);
	assert(pos.ToString() == "m_i = 5");
	assert(pos.GetInteger() == 5);

	// Test Case 2: ToString() with negative integer
	Integer neg(-10);
	assert(neg.ToString() == "m_i = -10");
	assert(neg.GetInteger() == -10);

	// Test Case 3: ToString() with zero
	Integer zero(0);
	assert(zero.ToString() == "m_i = 0");
	assert(zero.GetInteger() == 0);

	// Test Case 4: ToHTML() with positive integer
	assert(pos.ToHTML() == "<html><body><b>m_i</b> = 5</body></html>");

	// Test Case 5: ToHTML() with negative integer
	assert(neg.ToHTML() == "<html><body><b>m_i</b> = -10</body></html>");

	// Test Case 6: ToHTML() with zero
	assert(zero.ToHTML() == "<html><body><b>m_i</b> = 0</body></html>");
}

int main() {
	RunTests();
	std::cout << "All tests passed!" << std::endl;
	return 0;
}

/*
- The user of the Integer class requested that integers be converted to HTML.
- Therefore, the author of the Integer class had to modify the class.
- Because SRP was not honoured, it affected OCP as well.
*/