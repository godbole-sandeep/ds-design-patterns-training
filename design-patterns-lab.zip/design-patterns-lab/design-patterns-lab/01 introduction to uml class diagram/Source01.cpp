#include <string>

struct Point {
	double x;
	double y;
};

class DC {};

class IDrawable {
public:
	virtual void Draw(DC* pdc) = 0;
};

class Shape {
public:
	Shape(Point from, Point to);
public:
	Point GetFrom() const;
	Point GetTo() const;
	void SetFrom(Point point);
	void SetTo(Point point);
private:
	Point m_from;
	Point m_to;
	std::string* m_text;
};

class Rectanlge : public Shape, public IDrawable {
public:
	void Draw(DC* pdc) override;
};

enum ShapeType {
	Line,
	Oval,
	Rectangle
};

class ShapeFactory {
public:
	Shape* CreateShape(ShapeType shapeType);
};