#include <iostream>


int main() {
	std::cout << "Your setup is good to go...." << std::endl;
	return 0;
}