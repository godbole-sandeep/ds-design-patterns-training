#include <assert.h>
#include <crtdbg.h>
#include <iostream>

class Integer {
public:
	Integer(int i);
public:
	int GetInteger() const;
private:
	int m_i;
};

Integer::Integer(int i) : m_i(i) {}

int Integer::GetInteger() const {
	return m_i;
}

class IntegerFactory {
public:
	Integer* CreateInteger(int i);
	void Release();
public:
	static IntegerFactory* GetInstance();
private:
	IntegerFactory() {}
private:
	static IntegerFactory* m_pIntegerFactory;
};

IntegerFactory* IntegerFactory::m_pIntegerFactory = nullptr;

Integer* IntegerFactory::CreateInteger(int i) {
	return new Integer(i);
}

void IntegerFactory::Release() {
	delete m_pIntegerFactory;
	m_pIntegerFactory = nullptr;
}

IntegerFactory* IntegerFactory::GetInstance() {
	if (m_pIntegerFactory == nullptr)
		m_pIntegerFactory = new IntegerFactory();
	return m_pIntegerFactory;
}

void RunTests() {
	// Test Case 1: Verify IntegerFactory::CreateInteger creates correct integer object
	{
		IntegerFactory* intFactoryPtr = IntegerFactory::GetInstance();
		Integer* intPtr = intFactoryPtr->CreateInteger(5);
		assert(intPtr->GetInteger() == 5);
		delete intPtr;
		intPtr = nullptr;
		intFactoryPtr->Release();
		intFactoryPtr = nullptr;
	}

	// Test Case 2: Verify Singleton nature of IntegerFactory
	{
		IntegerFactory* instance1 = IntegerFactory::GetInstance();
		IntegerFactory* instance2 = IntegerFactory::GetInstance();
		assert(instance1 == instance2);  // Both should be the same instance
		instance1->Release();
		instance2->Release();
		instance1 = nullptr;
		instance2 = nullptr;
	}

	// Test Case 3: Verify IntegerFactory::CreateInteger with negative integer
	{
		IntegerFactory* intFactoryPtr = IntegerFactory::GetInstance();
		Integer* intPtr = intFactoryPtr->CreateInteger(-10);
		assert(intPtr->GetInteger() == -10);
		delete intPtr;
		intPtr = nullptr;
		intFactoryPtr->Release();
		intFactoryPtr = nullptr;
	}

	// Test Case 4: Verify IntegerFactory::CreateInteger with zero
	{
		IntegerFactory* intFactoryPtr = IntegerFactory::GetInstance();
		Integer* intPtr = intFactoryPtr->CreateInteger(0);
		assert(intPtr->GetInteger() == 0);
		delete intPtr;
		intPtr = nullptr;
		intFactoryPtr->Release();
		intFactoryPtr = nullptr;
	}

	// Test Case 5: Memory deallocation
	{
		IntegerFactory* intFactoryPtr = IntegerFactory::GetInstance();
		Integer* intPtr = intFactoryPtr->CreateInteger(5);
		int i = intPtr->GetInteger(); // Save value before deletion
		delete intPtr;
		intPtr = nullptr;
		intFactoryPtr->Release();
		intFactoryPtr = nullptr;
		assert(_CrtDumpMemoryLeaks() == 0);
	}
}

int main() {
	RunTests();
	std::cout << "All tests passed!" << std::endl;
	return 0;
}