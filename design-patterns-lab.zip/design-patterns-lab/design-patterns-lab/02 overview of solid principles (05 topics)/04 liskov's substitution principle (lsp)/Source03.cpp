#include <assert.h>
#include <iostream>
#include <typeinfo>

class NotImplementedException {};

class Object {
public:
	virtual const type_info& GetType() = 0;
	virtual void* Clone() = 0;
};

class Integer : public Object {
public:
	Integer(int i);
public:
	int GetInteger() const;
public:
	const type_info& GetType();
	void* Clone();
private:
	int m_i;
};

Integer::Integer(int i) : m_i(i) {}

int Integer::GetInteger() const {
	return m_i;
}

const type_info& Integer::GetType() {
	return typeid(*this);
}

void* Integer::Clone() {
	return new Integer(m_i);
}

class IntegerFactory : public Object {
public:
	Integer* CreateInteger(int i);
	void Release();
public:
	static IntegerFactory* GetInstance();
private:
	IntegerFactory() {}
public:
	const type_info& GetType();
	void* Clone();
private:
	static IntegerFactory* m_pIntegerFactory;
};

IntegerFactory* IntegerFactory::m_pIntegerFactory = nullptr;

Integer* IntegerFactory::CreateInteger(int i) {
	return new Integer(i);
}

void IntegerFactory::Release() {
	delete m_pIntegerFactory;
	m_pIntegerFactory = nullptr;
}

IntegerFactory* IntegerFactory::GetInstance() {
	if (m_pIntegerFactory == nullptr)
		m_pIntegerFactory = new IntegerFactory();
	return m_pIntegerFactory;
}

const type_info& IntegerFactory::GetType() {
	return typeid(*this);
}

void* IntegerFactory::Clone() {
	throw NotImplementedException();
}

void RunTests() {
	// Test Case 1: Verify cloning of Integer object
	{
		IntegerFactory* intFactoryPtr = IntegerFactory::GetInstance();
		Integer* intPtr = intFactoryPtr->CreateInteger(5);
		Integer* clonedIntPtr = static_cast<Integer*>(intPtr->Clone());
		assert(intPtr->GetInteger() == clonedIntPtr->GetInteger());  // Values should be the same
		assert(intPtr != clonedIntPtr);  // Pointers should not be the same (deep copy)
		delete intPtr;
		delete clonedIntPtr;
		intPtr = nullptr;
		clonedIntPtr = nullptr;
		intFactoryPtr->Release();
	}

	// Test Case 2: Verify GetType for Integer object
	{
		IntegerFactory* intFactoryPtr = IntegerFactory::GetInstance();
		Integer* intPtr = intFactoryPtr->CreateInteger(5);
		assert(intPtr->GetType() == typeid(Integer));  // Type should be Integer
		delete intPtr;
		intPtr = nullptr;
		intFactoryPtr->Release();
	}

	// Test Case 3: Verify GetType for Integer and IntegerFactory objects
	{
		IntegerFactory* intFactoryPtr = IntegerFactory::GetInstance();
		Integer* intPtr = intFactoryPtr->CreateInteger(5);
		assert(intPtr->GetType() == typeid(Integer));  // Type should be Integer
		assert(intFactoryPtr->GetType() == typeid(IntegerFactory));  // Type should be IntegerFactory
		delete intPtr;
		intPtr = nullptr;
		intFactoryPtr->Release();
	}

	// Test Case 4: Verify IntegerFactory::Clone() throws NotImplementedException
	{
		IntegerFactory* intFactoryPtr = IntegerFactory::GetInstance();
		bool exceptionThrown = false;
		try {
			intFactoryPtr->Clone();
		}
		catch (const NotImplementedException&) {
			exceptionThrown = true;
		}
		intFactoryPtr->Release();
		assert(exceptionThrown);  // Exception should be thrown
	}
}

int main() {
	RunTests();
	std::cout << "All tests passed!" << std::endl;
	return 0;
}

/*
- The implementation of the Object interface on IntegerFactory clearly
  violates the Liskov Substitution Principle (LSP).
- Liskov Substitution Principle states that derived types must be
  completely substitutable for their base types.
*/