#include <assert.h>
#include <iostream>
#include <sstream>
#include <string>

class Integer {
public:
	Integer(int i);
public:
	int GetInteger() const;
private:
	int m_i;
};

Integer::Integer(int i) : m_i(i) {}

int Integer::GetInteger() const {
	return m_i;
}

class Format {
public:
	static std::string ToString(const Integer& obj);
	static std::string ToHTML(const Integer& obj);
};

std::string Format::ToString(const Integer& obj) {
	std::stringstream ss;
	ss << "m_i = " << obj.GetInteger();
	return ss.str();
}

std::string Format::ToHTML(const Integer& obj) {
	std::stringstream ss;
	ss << "<html><body><b>m_i</b> = " << obj.GetInteger() << "</body></html>";
	return ss.str();
}

void RunTests() {
	// Test Case 1: ToString() with positive integer
	Integer pos(5);
	assert(Format::ToString(pos) == "m_i = 5");
	assert(pos.GetInteger() == 5);

	// Test Case 2: ToString() with negative integer
	Integer neg(-10);
	assert(Format::ToString(neg) == "m_i = -10");
	assert(neg.GetInteger() == -10);

	// Test Case 3: ToString() with zero
	Integer zero(0);
	assert(Format::ToString(zero) == "m_i = 0");
	assert(zero.GetInteger() == 0);

	// Test Case 4: ToHTML() with positive integer
	assert(Format::ToHTML(pos) == "<html><body><b>m_i</b> = 5</body></html>");

	// Test Case 5: ToHTML() with negative integer
	assert(Format::ToHTML(neg) == "<html><body><b>m_i</b> = -10</body></html>");

	// Test Case 6: ToHTML() with zero
	assert(Format::ToHTML(zero) == "<html><body><b>m_i</b> = 0</body></html>");
}

int main() {
	RunTests();
	std::cout << "All tests passed!" << std::endl;
	return 0;
}

/*
- The methods that convert integers to strings or HTML have been factored out.
- This makes the Integer class honour the single responsibility principle.
- SRP states that a class should have only one reason to change.
- The Integer class now has only one reason to change: if the way the integer
  is stored or accessed changes.
- Give one entity one cohesive (means very closely related) responsibility.
*/