#include <assert.h>
#include <iostream>
#include <sstream>
#include <string>

class Integer {
public:
	Integer(int i);
public:
	int GetInteger() const;
public:
	std::string ToString() const;
private:
	int m_i;
};

Integer::Integer(int i) : m_i(i) {}

int Integer::GetInteger() const {
	return m_i;
}

std::string Integer::ToString() const {
	std::stringstream ss;
	ss << "m_i = " << m_i;
	return ss.str();
}

void RunTests() {
	// Test Case 1: ToString() with positive integer
	Integer pos(5);
	assert(pos.ToString() == "m_i = 5");
	assert(pos.GetInteger() == 5);

	// Test Case 2: ToString() with negative integer
	Integer neg(-10);
	assert(neg.ToString() == "m_i = -10");
	assert(neg.GetInteger() == -10);

	// Test Case 3: ToString() with zero
	Integer zero(0);
	assert(zero.ToString() == "m_i = 0");
	assert(zero.GetInteger() == 0);
}

int main() {
	RunTests();
	std::cout << "All tests passed!" << std::endl;
	return 0;
}

/*
- The Single Responsibility Principle (SRP) states that a class should have only one reason to change,
  meaning it should have only one job or responsibility.
- In the example, the Integer class performs two primary functions:
  1. Holding an integer value: The class stores an integer value and provides access to it through
	 the GetInteger method.
  2. Converting the integer to a string: The class provides a method ToString to convert the
	 integer value to a string representation.
- While the Integer class is relatively simple and these responsibilities might seem closely related,
  strictly speaking, it does violate the Single Responsibility Principle because it has two reasons to
  change:
  1. If the way the integer is stored or accessed changes.
  2. If the way the integer is converted to a string changes.
- If a change in the system leads to the proliferation of multiple versions of the same class,
  it indicates a violation of the Single Responsibility Principle (SRP).
*/