#pragma once

#include "ISubject.h"

#ifndef REALSUBJECT_H
#define REALSUBJECT_H

#include <string>

class RealSubject : public ISubject {
public:
    void DoSomething(const std::string& message) const override;
};

#endif // REALSUBJECT_H