#include <iostream>
#include <memory> // for std::unique_ptr

#include "ISubject.h"
#include "LoggingProxy.h"
#include "RealSubject.h"

int main() {
	// Create a unique_ptr for the logging proxy with the real subject ownership transfered
	std::unique_ptr<ISubject> proxy = std::make_unique<LoggingProxy>(std::make_unique<RealSubject>());

	// Call DoSomething through the proxy (logging happens here)
	proxy->DoSomething("This is a message");

	return 0;
}