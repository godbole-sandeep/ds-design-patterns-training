#include <iostream>

#include "RealSubject.h"

void RealSubject::DoSomething(const std::string& message) const {
    std::cout << "Real subject doing something: " << message << std::endl;
}