#pragma once

class ISubject {
public:
	virtual void DoSomething() const = 0;
};