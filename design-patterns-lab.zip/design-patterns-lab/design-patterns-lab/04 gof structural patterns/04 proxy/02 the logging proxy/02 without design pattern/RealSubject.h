#pragma once

#include <string>

#include "ISubject.h"

class RealSubject : public ISubject {
public:
    void DoSomething() const override;
};