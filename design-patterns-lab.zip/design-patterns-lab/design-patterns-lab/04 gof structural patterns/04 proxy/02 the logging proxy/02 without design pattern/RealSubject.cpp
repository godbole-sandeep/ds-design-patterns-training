#include <iostream>

#include "RealSubject.h"

void RealSubject::DoSomething() const {
    std::cout << "Real subject doing something: " << std::endl;
}