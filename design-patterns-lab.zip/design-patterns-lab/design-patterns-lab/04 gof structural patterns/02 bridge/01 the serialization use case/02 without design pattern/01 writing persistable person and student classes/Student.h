#pragma once

#ifndef STUDENT_H
#define STUDENT_H

#include "person.h"

class Student : public Person {
public:
    Student(const std::string& name, int age, int studentID);
public:
    int GetStudentID() const;
public:
    void Save() const override;
private:
    int m_studentID;
};

#endif // STUDENT_H
