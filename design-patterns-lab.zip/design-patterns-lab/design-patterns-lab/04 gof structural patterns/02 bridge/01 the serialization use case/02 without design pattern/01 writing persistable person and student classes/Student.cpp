#include <iostream>

#include "Student.h"

Student::Student(const std::string& name, int age, int studentID)
    : Person(name, age), m_studentID(studentID) {}

int Student::GetStudentID() const {
    return m_studentID;
}

void Student::Save() const {
    std::cout << "The following student's record is stored in the file." << std::endl;
    std::cout << "Name: " << GetName() << ", Age: " << GetAge() << ", Student ID: " << m_studentID << ", ";
}