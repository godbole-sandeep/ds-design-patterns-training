#pragma once


#ifndef DBSERIALIZEDPERSON_H
#define DBSERIALIZEDPERSON_H

#include "Person.h"

class DbSerializedPerson :
    public Person {
public:
    DbSerializedPerson(const std::string& name, int age);
public:
    void Save() const override;
};

#endif