#include "DbSerializedPerson.h"
#include "DbSerializedStudent.h"

int main() {
    // Create a DbSerializedPerson object
    DbSerializedPerson person("Smita", 30);

    // Save person's data to database
    person.Save();

    // Create a DbSerializedStudent object
    DbSerializedStudent student("Mukund", 25, 12345);

    // Save student's data to database
    student.Save();

    return 0;
}
