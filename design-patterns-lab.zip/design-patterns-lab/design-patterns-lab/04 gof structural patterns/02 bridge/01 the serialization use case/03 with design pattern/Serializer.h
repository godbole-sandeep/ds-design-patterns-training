#pragma once

#ifndef SERIALIZER_H
#define SERIALIZER_H

#include <string>

class Serializer {};

#endif