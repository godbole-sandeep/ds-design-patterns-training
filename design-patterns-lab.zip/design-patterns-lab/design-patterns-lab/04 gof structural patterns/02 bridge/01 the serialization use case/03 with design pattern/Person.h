#pragma once

#ifndef PERSON_H
#define PERSON_H

#include <memory>
#include <string>

#include "Serializer.h"

class Person {
public:
    Person(const std::string& name, int age);
    virtual ~Person() = default;
public:
    const std::string& GetName() const;
    int GetAge() const;
public:
    virtual void Save() const;
private:
    std::string m_name;
    int m_age;
};

#endif // PERSON_H