#include <iostream>

#include "Student.h"

Student::Student(const std::string& name, int age, int studentID)
    : Person(name, age), m_studentID(studentID) {}

int Student::GetStudentID() const {
    return m_studentID;
}

void Student::Save() const {}