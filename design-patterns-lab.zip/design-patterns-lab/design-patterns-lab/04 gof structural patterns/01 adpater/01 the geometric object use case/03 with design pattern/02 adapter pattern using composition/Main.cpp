#include <memory>

#include "GeometricObject.h"
#include "Oval.h"
#include "Rectangle.h"
#include "Triangle.h"

void Draw(std::shared_ptr<GeometricObject> geometricObject) {
    geometricObject->Draw();
}

// NOT REQUIRED
//void Draw(std::shared_ptr<CTriangle> triangle) {
//    triangle->Show();
//}

int main() {
    std::shared_ptr<GeometricObject> rectangle = std::make_shared<Rectangle>();
    std::shared_ptr<GeometricObject> oval = std::make_shared<Oval>();
    std::shared_ptr<GeometricObject> triangle = std::make_shared<Triangle>();

    Draw(rectangle);
    Draw(oval);
    Draw(triangle);

    return 0;
}

/*
- Adapter pattern can be implemented using private inheritance and composition.
- So, which method should be used?
- Always prefer compostion over inheritance.
- Hence composition method should be used to implement Adapter pattern.
*/