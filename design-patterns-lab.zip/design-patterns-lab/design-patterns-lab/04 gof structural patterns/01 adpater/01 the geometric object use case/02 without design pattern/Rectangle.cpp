#include <iostream>

#include "Rectangle.h"

void Rectangle::Draw() {
	std::cout << "Drawing a rectangle." << std::endl;
}