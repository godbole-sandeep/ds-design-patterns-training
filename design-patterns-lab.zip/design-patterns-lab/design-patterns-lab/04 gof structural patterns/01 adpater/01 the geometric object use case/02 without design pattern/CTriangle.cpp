#include <iostream>

#include "CTriangle.h"

void CTriangle::Show() {
    std::cout << "Showing a Triangle." << std::endl;
}