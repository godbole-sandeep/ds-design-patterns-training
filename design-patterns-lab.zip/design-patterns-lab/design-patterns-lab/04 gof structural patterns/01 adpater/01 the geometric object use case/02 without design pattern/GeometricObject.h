#pragma once

#ifndef GEOMETRICOBJECT_H
#define GEOMETRICOBJECT_H

class GeometricObject {
public:
    virtual ~GeometricObject() = default;
    virtual void Draw() = 0;
};

#endif // GEOMETRICOBJECT_H